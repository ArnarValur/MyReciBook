# DittoDatto Design System

The design system for **DittoDatto** — an agentic commerce & service-booking
marketplace for Norway (dittodatto.no). It lets designers and agents produce
correctly-branded DittoDatto interfaces and assets.

> **Tagline:** *Ditto* (the consumer) + *Datto* (the business) — an agentic
> booking system. Book time with hairdressers, restaurants, clinics, gyms and
> local services across Norway.

---

## Products

DittoDatto is a multi-surface product family, all sharing this Material 3–based
design language:

1. **Consumer app** — Flutter, mobile-first. Anonymous discovery + service
   booking. Light "Stitch Enterprise Slate" theme with a solar auto-theme.
   → recreated in `ui_kits/consumer_app/`.
2. **Business / admin portals** — Flutter web. Dashboard for establishments to
   manage bookings, services and customers. Dark "Midnight Admin" theme.
   → recreated in `ui_kits/business_portal/`.
3. **Landing page** — Nuxt marketing site (dittodatto.no) under `web/*`.
   ⚠️ **Legacy / possibly unmaintained** — per the team, the canonical product
   is the Flutter app in `apps/marketplace`. No UI kit is built for the Nuxt
   site; treat its patterns as non-authoritative.

The whole family is Material 3, seeded from **Moody Blue `#3F51B5`**, on an
**8px rhythm** (4px sub-unit), with pill search bars, and a **navy (not black)**
dark mode.

---

## Sources this system was built from

Everything here was reverse-engineered from real, provided sources — nothing
was invented. If you have access, consult:

- **`packages/ditto_design`** (Flutter design-system package) — the token
  source of truth: `ditto_colors.dart`, `ditto_spacing.dart`,
  `ditto_border_radius.dart`, `ditto_elevation.dart`, `ditto_animation.dart`,
  `ditto_theme.dart` (light + dark ThemeData), plus layout shells
  (`ditto_dashboard_shell.dart`, `ditto_scrollspy_layout.dart`) and shared
  widgets (`ditto_confirm_dialog.dart`, `ditto_empty_view.dart`,
  `ditto_error_view.dart`).
- **`marketplace`** (Flutter consumer app) — real screens: `home_screen.dart`,
  `establishment_listing_card.dart`, `bookings_screen.dart`,
  `profile_screen.dart`, `login_screen.dart`, and the spatial shell
  (`ditto_bar.dart`, `ditto_nav_bar.dart`, `glass_panel.dart`,
  `solar_background.dart`, `inline_auth_form.dart`).
- **`DESIGN.md`** — the M3 token export (full light color scheme + type scale).
- **`marketplace_styles_inventory.md`** — an audit of tokens, theming, the
  Solar Engine, and layout patterns.
- **`assets/brand-cover.jpeg`** — provided brand cover / wordmark.

> **Known token discrepancy (documented in the source):** older context cites
> Moody Blue as `#6F71CC`, but the shipped implementation
> (`ditto_colors.dart`) uses **`#3F51B5`**. This system uses `#3F51B5`.

---

## Brand & personality

**Moody Blue. Corporate Modern with a Soft Edge. Composed energy.**

DittoDatto balances the systematic precision of Material Design with custom
curves and deep tonal layering. It should feel *reliable yet expressive* —
professional enough for enterprise (the business portal), tactile enough for
consumer engagement (the app). Subtle gradients and soft elevations guide the
eye without overwhelming.

---

## CONTENT FUNDAMENTALS

**Language.** All product UI is **Norwegian (Bokmål)**. Write copy in Norwegian;
keep it natural, not translated-sounding.

**Voice.** Warm, direct, plain-spoken. Short sentences. It addresses the user
informally with **"du/deg/din"** ("Logg inn på kontoen din", "Skriv inn
passordet ditt"). Confident and reassuring, never salesy.

**Casing.** Sentence case everywhere — buttons, titles, labels
("Logg inn", "Mine bestillinger", "Opprett konto"). No ALL-CAPS except tiny
metadata labels tracked out (section headers like "KOMMENDE"). Norwegian keeps
lowercase weekday/month names ("lørdag", "5. jul").

**Emoji.** Used *sparingly* and only as a warm human accent — the profile
greeting "Hei, {navn} 👋" is the canonical (nearly only) example. Never use
emoji as functional icons; that is the Material Symbols system's job.

**Tone examples (verbatim from the app):**
- Search placeholder: *"Søk etter tjenester, steder, bedrifter..."*
- Empty bookings: *"Ingen bestillinger ennå"* / *"Utforsk våre tjenester for å finne din neste time."*
- Zero search results (a *signal*, not an error): *"Ingen treff for «…»"* / *"Vi har notert det — DittoDatto vokser, og ditt søk hjelper oss å vokse riktig."*
- Login gate: *"Krever innlogging"* / *"Logg inn for å se dine bestillinger, administrere kommende avtaler og se historikk."*
- Errors are calm and actionable: *"Kunne ikke laste virksomheter"* + a *"Prøv igjen"* retry.

**Booking status labels:** Bekreftet · Fullført · Avbestilt · Ikke møtt ·
Endret · Venter.

**Microcopy quirks:** the `→` arrow appears on primary CTAs ("Logg inn →").
Voice search is branded *stemmesøk*; the search flow is *søkeflyt*.

---

## VISUAL FOUNDATIONS

**Color.** Rooted in the Moody Blue spectrum. Primary `#24389C` (M3-derived from
the `#3F51B5` seed) carries key brand moments and primary buttons; secondary
`#4D5A9C` handles tints, chips and tonal buttons; a high-contrast magenta-pink
tertiary (`#B40050` / `#88003B`) is reserved for CTA/notification moments and
used *sparingly*. Neutrals are cool grays in light mode, deep navies in dark.
See `tokens/colors.css`.

**Two themes.**
- *Light — "Stitch Enterprise Slate"*: clean and airy. Cream scaffold `#FAF8F0`,
  white/`#F9F9FC` containers, dual-font type. The consumer app default.
- *Dark — "Midnight Admin"*: high-tech midnight-blue. Scaffold `#0F1117`, cards
  `#161922`. **Deep navy, never pure black**, so soft shadows/elevations stay
  visible. Uses Inter globally. The admin/business portal default.
- *Solar auto* (consumer): the **SolarTheme** — see its own section below.

**Type.** Dual-font. **Plus Jakarta Sans** (friendly rounded-geometric) for
display/headline — tight tracking (−0.02em) on large display. **Inter** for
body/label — maximum legibility in data-heavy screens. Display 48/56·700,
headline 32/40 & 24/32·600, body 18/28 & 16/24·400, labels 14·500 / 12·600.
See `tokens/typography.css`.

**Spacing & layout.** 8px rhythm, 4px sub-unit (xs4 · sm8 · compact12 · md16 ·
lg24 · xl32). Mobile: 4-col grid, 20px margins, 16px gutters. Desktop: 12-col,
max content width ~1200px, centered. See `tokens/spacing.css`.

**Shape / corners.** Rounded Level 2. 8px for buttons & small inputs; 12px for
inputs & listing cards; 16px for cards, dialogs & sheets; 24px for bottom
sheets; **full (9999px)** exclusively for pills — search bars, chips, avatars,
FABs.

**Cards.** Surface-container-lowest fill, a *hairline* border (outline-variant
at ~50%), 12–16px radius, and a soft **blue-tinted** Level-1 shadow
(`0 4px 10px rgba(36,56,156,.06)`). Interactive cards lift 2px on hover to a
Level-2 shadow.

**Elevation & depth.** Tonal layers + soft ambient shadows tinted with the
primary blue (L1 blur10/y4/6%, L2 blur20/y8/12%). A **Moody Blue accent glow**
(`rgba(63,81,181,.15)`, blur 12, spread 2) marks focus/active. In dark mode,
elevation is shown through **surface tinting** (a lighter navy), because shadows
read weakly on navy. See `tokens/elevation.css`.

**Glassmorphism.** A signature motif. The bottom nav, the floating search sheet
(DittoBar), and inline panels are **frosted glass** — 20–24px backdrop blur, a
translucent black/white fill, and a hairline border — floating over the map /
solar gradient (`extendBody`). The `GlassPanel` and `NavBar` components own this.

**Backgrounds & imagery.** Mostly flat token surfaces (cream / navy). Full-bleed
gradients appear only behind glass (nav, search overlay) and on the solar
background. Establishment imagery is 16:9 photographic covers with a circular
logo overlaid bottom-left. Imagery is neutral/true-to-life (no heavy filters or
grain). Gradients are diagonal indigo→magenta, used sparingly for the FAB and
glass stages.

**Borders.** Hairline (1px) throughout; light mode uses outline-variant at ~50%
alpha, dark mode uses white at 6–12% alpha. Focused inputs thicken the bottom/
full border to **1.5px primary**.

**Buttons.** Filled = solid primary, white text, 8px radius, Level-1 shadow.
Tonal = secondary-container fill. Outlined = 1.5px secondary border, no fill.
Text = primary label. Danger = solid error. 14px semibold labels.

**Motion.** Purposeful, never bouncy. Durations 150ms (micro / hover), 300ms
(standard transitions), 500ms (deliberate). M3 emphasized easing
`cubic-bezier(0.2,0,0,1)`. FAB icon cross-fades + scales on state change; the
solar background cross-fades over ~2s. Respect `prefers-reduced-motion`.

**Hover / press.** Hover: subtle background tint or a 2px card lift + deeper
shadow. Press: opacity/tonal darkening (Flutter InkWell ripple in-app). Primary
actions add haptic feedback on the device.

---

## SolarTheme — the living atmospheric theme

DittoDatto's signature (still-evolving) theme. Instead of a manual light/dark
toggle, the consumer app can let the **real-time position of the sun over
Drammen, Norway (59.74°N, 10.20°E)** drive a smooth, continuous transition
between light and dark — because in Norway twilight stretches and shrinks
dramatically with the **season**, the theme's behaviour changes across the year,
not just across the day.

**How it works** (`solar/solar-engine.js`, a faithful JS port of the Flutter
`SolarEngine` + `SunCalc`, itself ported from the Nuxt `useSolarEngine.ts`):

1. **Sun position** — `SunCalc.getPosition(date, lat, lng)` computes true solar
   altitude/azimuth astronomically (no lookup tables).
2. **Dynamic lightness floor** — the day's *minimum* sun altitude is sampled and
   mapped to a floor: `5 + clamp((minAlt+18)/18, 0, 1) · 25`. In deep winter the
   sun drops below −18°, so the floor is 5% (true night, stars out). In Nordic
   summer the sun barely dips (Drammen 21 Jun ≈ −7.5°), so the floor rises to
   ~20% — **midsummer nights never go pitch-black**, which is the whole point.
3. **Lightness** — a perceptual sigmoid of altitude: `−20°→floor`, `60°→95%`,
   accelerating through twilight.
4. **Hue stays Moody Blue (237°)** — it never lerps toward golden, because
   237→40 would pass through green; the Scandinavian sky stays blue.
5. **Warm twilight** is faked with a *saturation* boost near the horizon
   (−2°…8°), then damped past 30% lightness for the washed "Nordic Studio"
   daylight feel.
6. **Stars** ramp in below −6° (`(|alt|−6)/12`).
7. **Phase** (Norwegian labels): Dag · Gyllen time · Borgerlig/Nautisk/
   Astronomisk skumring · Natt. **Dark mode** engages when lightness < 45%.

**Use it:** `<script src="solar/solar-engine.js">` then
`const st = DittoSolar.SolarEngine.compute(new Date());` → `{ lightness, hue,
saturation, phase, starOpacity, isDark }`, plus `DittoSolar.SolarEngine
.skyGradient(st)` for the two-stop sky CSS. The live specimen (drag hour +
season) is `guidelines/brand-solar.card.html` (Design System tab → Brand).
Reference Dart source: `solar/*.dart`.

---

## ICONOGRAPHY

**One system: Material Symbols Rounded.** The Flutter apps use `Icons.*_rounded`
everywhere — there is no custom icon set, no SVG sprite, no PNG icons in the
codebase. This DS loads **Material Symbols Rounded** from Google Fonts and wraps
it in the `Icon` component. Default optical size 24, weight 400; use the *filled*
axis for active/selected states (active nav item, favorite heart, rating star).

- **Never** hand-roll SVG icons or substitute emoji for glyphs.
- Common glyphs in use: `search`, `explore`, `calendar_today` / `calendar_month`,
  `near_me`, `person`, `storefront`, `content_cut`, `restaurant`, `spa`,
  `fitness_center`, `local_hospital`, `event`, `favorite`, `star`, `mic`,
  `check_circle`, `schedule`, `arrow_forward`, `chevron_right`, `logout`,
  `settings`, `dashboard`, `group`.
- Category chips map a stored icon name → a Material glyph (see
  `home_screen.dart`'s `_iconMap`).

**Logo / brand mark.** The DittoDatto mark is a **pocket / shield "D"** — a
rounded square-bottom outline with an overlapping smile curve inside, drawn in
the two brand indigos (a light periwinkle top over a deep-indigo bottom, echoing
the light↔dark theme split). Files: `assets/logo.png` (1024×1024, transparent).

- On light surfaces, use as-is. On the primary blue, knock it out to white
  (`filter: brightness(0) invert(1)`). On dark navy, pair the mark with the
  wordmark for balance.
- **Wordmark:** "DittoDatto" in **Plus Jakarta Sans 800, primary color**,
  −0.02em tracking. The mark + wordmark lockup is the app's home header.
- Keep clear space of ≥ half the mark's height around it. Don't recolor the mark
  outside the brand indigos or add effects. See `guidelines/brand-logo.card.html`.

---

## Foundations at a glance

| Token file | Concern |
|---|---|
| `tokens/colors.css` | Light + dark palettes, primary/secondary/tertiary, surfaces, status, glass tints |
| `tokens/typography.css` | Font families, type scale, `.ditto-*` utility classes |
| `tokens/spacing.css` | 4px spacing grid, radii, layout margins |
| `tokens/elevation.css` | Shadows, focus glow, blur, motion durations/easing |
| `tokens/fonts.css` | Google Fonts import (Plus Jakarta Sans + Inter) |

`styles.css` (root) is the single entry point consumers link — an `@import`
manifest only.

---

## Components (`window.DittoDattoDesignSystem_1b21a0`)

Reusable primitives, grouped by concern. Each has a `.jsx`, `.d.ts`,
`.prompt.md`, and a demo card.

- **forms/** — **Button**, **Input**, **SearchBar** (DittoBar), **Chip** (FilterChip)
- **surfaces/** — **Card**, **GlassPanel**
- **data-display/** — **Badge** (+ `BOOKING_STATUS`), **Avatar**, **RatingBadge**, **ListingCard**
- **feedback/** — **Dialog**, **EmptyState**
- **navigation/** — **NavBar** (glass bottom nav + FAB)
- **icon/** — **Icon** *(intentional addition — a thin Material Symbols Rounded wrapper so recreations never hand-roll SVGs; the codebase's single icon system)*

## UI kits

- **`ui_kits/consumer_app/`** — mobile marketplace: discovery, establishment
  detail, booking, bookings, profile/auth, glass nav + search overlay.
- **`ui_kits/business_portal/`** — dark admin dashboard: sidebar shell, KPIs,
  booking management table.

## Templates ("Use Design" starting points)

Consuming projects seed new designs from `templates/`:

- **`templates/consumer-app/`** — mobile marketplace screen (light, editable markup).
- **`templates/business-portal/`** — dark admin dashboard (Midnight Admin).
- **`templates/branded-page/`** — blank branded page: tokens, fonts & logo header loaded.

## Assets

- `assets/logo.png` — the DittoDatto pocket-shield brand mark (transparent PNG).
- `assets/brand-cover.jpeg` — earlier brand cover / wordmark study (mascot lockup; note its orange accent is not part of the product palette).

## Root manifest

- `styles.css` — global entry (import manifest)
- `tokens/` — CSS custom properties (see table above)
- `components/` — reusable primitives + demo cards
- `ui_kits/` — full-screen product recreations
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand)
- `solar/` — SolarTheme engine (`solar-engine.js`) + reference Dart source
- `assets/` — brand imagery
- `SKILL.md` — Agent-Skills–compatible entry point

---

## Caveats

- **Fonts are Google-hosted** (Plus Jakarta Sans + Inter) — these are the real
  brand fonts (loaded in-app via the `google_fonts` package), so no substitution
  was needed.
- **Listing photos** in the consumer kit are Lorem Picsum placeholders — swap
  for real establishment photography.
- **Landing page** (Nuxt) has no UI kit — its source wasn't provided.
