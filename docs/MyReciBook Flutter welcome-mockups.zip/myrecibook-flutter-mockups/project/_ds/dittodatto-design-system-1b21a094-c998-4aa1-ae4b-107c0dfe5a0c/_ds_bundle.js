/* @ds-bundle: {"format":4,"namespace":"DittoDattoDesignSystem_1b21a0","components":[{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"BOOKING_STATUS","sourcePath":"components/data-display/Badge.jsx"},{"name":"ListingCard","sourcePath":"components/data-display/ListingCard.jsx"},{"name":"RatingBadge","sourcePath":"components/data-display/RatingBadge.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Chip","sourcePath":"components/forms/Chip.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"SearchBar","sourcePath":"components/forms/SearchBar.jsx"},{"name":"Icon","sourcePath":"components/icon/Icon.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"GlassPanel","sourcePath":"components/surfaces/GlassPanel.jsx"}],"sourceHashes":{"components/data-display/Avatar.jsx":"3ea8bd47668d","components/data-display/Badge.jsx":"4ac06e4202f0","components/data-display/ListingCard.jsx":"40d358369a62","components/data-display/RatingBadge.jsx":"1722b6b840e6","components/feedback/Dialog.jsx":"e3ed7e654e97","components/feedback/EmptyState.jsx":"c950ac28fcae","components/forms/Button.jsx":"f92cc1a52e9f","components/forms/Chip.jsx":"4ecd18bb4191","components/forms/Input.jsx":"fa70c9efcf74","components/forms/SearchBar.jsx":"653bffd702e7","components/icon/Icon.jsx":"a7416eaf5cdd","components/navigation/NavBar.jsx":"0e8d8d28f987","components/surfaces/Card.jsx":"0eca237e2b9e","components/surfaces/GlassPanel.jsx":"8de987d7e187","solar/solar-engine.js":"5a479a77801b","ui_kits/business_portal/app.jsx":"78af29a76ced","ui_kits/consumer_app/app.jsx":"4d4fd22403e1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DittoDattoDesignSystem_1b21a0 = window.DittoDattoDesignSystem_1b21a0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Avatar — circular user token. Renders an image when `src` is given,
 * otherwise initials on a tinted primary background.
 */
function Avatar({
  src,
  name = '',
  size = 48,
  style = {},
  ...rest
}) {
  const initials = name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map(p => p[0].toUpperCase()).join('') || '?';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: 'var(--radius-full)',
      background: src ? 'transparent' : 'color-mix(in srgb, var(--primary) 12%, transparent)',
      color: 'var(--primary)',
      display: 'grid',
      placeItems: 'center',
      overflow: 'hidden',
      flexShrink: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: size * 0.38,
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  primary: {
    bg: 'color-mix(in srgb, var(--primary) 15%, transparent)',
    fg: 'var(--primary)'
  },
  success: {
    bg: 'color-mix(in srgb, var(--success) 12%, transparent)',
    fg: 'var(--success)'
  },
  warning: {
    bg: 'color-mix(in srgb, var(--warning) 12%, transparent)',
    fg: 'var(--warning)'
  },
  error: {
    bg: 'color-mix(in srgb, var(--error) 12%, transparent)',
    fg: 'var(--error)'
  },
  neutral: {
    bg: 'color-mix(in srgb, var(--on-surface) 6%, transparent)',
    fg: 'var(--on-surface-variant)'
  },
  premium: {
    bg: 'color-mix(in srgb, var(--badge-premium) 14%, transparent)',
    fg: 'var(--badge-premium)'
  }
};

/**
 * Badge — small tonal status pill. Used for booking statuses
 * (Bekreftet, Fullført, Avbestilt…), tiers, and category tags.
 */
function Badge({
  children,
  tone = 'neutral',
  icon,
  style = {},
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      padding: '4px 8px',
      borderRadius: 'var(--radius-sm)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-body)',
      fontSize: 11,
      fontWeight: 'var(--weight-bold)',
      letterSpacing: '0.3px',
      lineHeight: 1.2,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 14
    }
  }, icon), children);
}

/** Booking-status → tone/label/icon map, matching the Flutter app. */
const BOOKING_STATUS = {
  confirmed: {
    tone: 'primary',
    label: 'Bekreftet',
    icon: 'check_circle'
  },
  completed: {
    tone: 'success',
    label: 'Fullført',
    icon: 'check_circle'
  },
  cancelled: {
    tone: 'neutral',
    label: 'Avbestilt',
    icon: 'cancel'
  },
  noShow: {
    tone: 'error',
    label: 'Ikke møtt',
    icon: 'event_busy'
  },
  rescheduled: {
    tone: 'neutral',
    label: 'Endret',
    icon: 'update'
  },
  pending: {
    tone: 'warning',
    label: 'Venter',
    icon: 'schedule'
  }
};
Object.assign(__ds_scope, { Badge, BOOKING_STATUS });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/RatingBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RatingBadge — amber star + average score + review count.
 * Matches the establishment listing card.
 */
function RatingBadge({
  average,
  count,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 2,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 15,
      color: '#f59e0b',
      fontVariationSettings: "'FILL' 1"
    }
  }, "star"), /*#__PURE__*/React.createElement("span", {
    className: "ditto-label-sm",
    style: {
      color: 'var(--on-surface)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, Number(average).toFixed(1)), count != null && /*#__PURE__*/React.createElement("span", {
    className: "ditto-label-sm",
    style: {
      color: 'var(--on-surface-variant)'
    }
  }, "(", count, ")"));
}
Object.assign(__ds_scope, { RatingBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/RatingBadge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ListingCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * EstablishmentListingCard — the discovery/home listing tile.
 * 16:9 cover with a circular logo overlay, then name, category chip +
 * rating row, and address. 16px radius, hairline border.
 */
function ListingCard({
  name,
  cover,
  logo,
  category,
  rating,
  address,
  city,
  open,
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const addressLine = city ? `${address}, ${city}` : address;
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: 'var(--surface-container-lowest)',
      borderRadius: 'var(--radius-lg)',
      border: '1px solid color-mix(in srgb, var(--outline-variant) 50%, transparent)',
      overflow: 'hidden',
      cursor: onClick ? 'pointer' : 'default',
      boxShadow: hover ? 'var(--elev-2)' : 'var(--elev-1)',
      transform: hover ? 'translateY(-2px)' : 'none',
      transition: 'box-shadow var(--dur-normal) var(--ease-standard), transform var(--dur-normal) var(--ease-standard)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '16 / 9',
      background: 'var(--surface-container-highest)'
    }
  }, cover ? /*#__PURE__*/React.createElement("img", {
    src: cover,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 48,
      color: 'color-mix(in srgb, var(--on-surface-variant) 40%, transparent)'
    }
  }, "storefront")), open != null && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 12,
      right: 12,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '5px 10px',
      borderRadius: 'var(--radius-full)',
      background: 'var(--glass-fill)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      border: '1px solid var(--glass-border)',
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 'var(--weight-semibold)',
      whiteSpace: 'nowrap',
      color: open ? 'var(--success)' : 'var(--on-surface-variant)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: open ? 'var(--success)' : 'var(--outline)'
    }
  }), open ? 'Åpent nå' : 'Stengt'), logo && /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "",
    style: {
      position: 'absolute',
      left: 12,
      bottom: 12,
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-full)',
      objectFit: 'cover',
      border: '2px solid var(--surface-container-lowest)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "ditto-headline-md",
    style: {
      margin: 0,
      fontSize: 16,
      lineHeight: '22px',
      color: 'var(--on-surface)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 6
    }
  }, category && /*#__PURE__*/React.createElement("span", {
    className: "ditto-label-sm",
    style: {
      padding: '2px 8px',
      borderRadius: 'var(--radius-sm)',
      background: 'color-mix(in srgb, var(--primary-container) 60%, transparent)',
      color: 'var(--on-primary-container)',
      fontWeight: 'var(--weight-medium)'
    }
  }, category), rating && /*#__PURE__*/React.createElement(__ds_scope.RatingBadge, {
    average: rating.average,
    count: rating.count
  })), addressLine && /*#__PURE__*/React.createElement("p", {
    className: "ditto-body-md",
    style: {
      margin: '6px 0 0',
      fontSize: 13,
      color: 'var(--on-surface-variant)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, addressLine)));
}
Object.assign(__ds_scope, { ListingCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ListingCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * EmptyState — centered icon + title + message + optional action.
 * Covers both the empty ("Ingen bestillinger ennå") and error
 * ("Kunne ikke laste") views. Set tone="error" for failures.
 */
function EmptyState({
  icon,
  title,
  message,
  action,
  tone = 'neutral',
  style = {},
  ...rest
}) {
  const iconColor = tone === 'error' ? 'var(--error)' : 'color-mix(in srgb, var(--primary) 40%, transparent)';
  const defaultIcon = tone === 'error' ? 'cloud_off' : 'inbox';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 8,
      padding: 32,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 56,
      color: iconColor,
      marginBottom: 8
    }
  }, icon || defaultIcon), title && /*#__PURE__*/React.createElement("div", {
    className: "ditto-headline-md",
    style: {
      fontSize: 18,
      color: 'var(--on-surface-variant)'
    }
  }, title), message && /*#__PURE__*/React.createElement("p", {
    className: "ditto-body-md",
    style: {
      margin: 0,
      maxWidth: 300,
      color: 'color-mix(in srgb, var(--on-surface-variant) 80%, transparent)',
      fontSize: 14
    }
  }, message), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * DittoDatto Button.
 * Variants mirror the Flutter theme: filled (primary), tonal
 * (secondary-container), outlined (1.5px secondary), and text.
 */
function Button({
  children,
  variant = 'filled',
  size = 'md',
  icon,
  trailingIcon,
  fullWidth = false,
  disabled = false,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 16px',
      fontSize: 13,
      minHeight: 36
    },
    md: {
      padding: '14px 24px',
      fontSize: 14,
      minHeight: 48
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--weight-semibold)',
    fontSize: s.fontSize,
    lineHeight: 1,
    padding: s.padding,
    minHeight: s.minHeight,
    width: fullWidth ? '100%' : 'auto',
    borderRadius: 'var(--radius-sm)',
    border: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-standard)',
    whiteSpace: 'nowrap'
  };
  const variants = {
    filled: {
      background: 'var(--primary)',
      color: 'var(--on-primary)',
      boxShadow: 'var(--elev-1)'
    },
    tonal: {
      background: 'var(--secondary-container)',
      color: 'var(--on-secondary-container)'
    },
    outlined: {
      background: 'transparent',
      color: 'var(--primary)',
      border: '1.5px solid var(--secondary)'
    },
    text: {
      background: 'transparent',
      color: 'var(--primary)',
      padding: size === 'sm' ? '8px 12px' : '12px 16px'
    },
    danger: {
      background: 'var(--error)',
      color: 'var(--on-error)',
      boxShadow: 'var(--elev-1)'
    }
  };
  const iconSize = size === 'sm' ? 18 : 20;
  const glyph = name => /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: iconSize,
      lineHeight: 1
    }
  }, name);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, rest), icon && glyph(icon), children, trailingIcon && glyph(trailingIcon));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
/**
 * Dialog — modal confirm. Scrim + centered rounded card with title,
 * message, and Cancel / Confirm actions. Confirm can be destructive.
 */
function Dialog({
  open = true,
  title,
  message,
  confirmLabel = 'Bekreft',
  cancelLabel = 'Avbryt',
  destructive = false,
  onConfirm,
  onCancel
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onCancel,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(15, 17, 23, 0.45)',
      display: 'grid',
      placeItems: 'center',
      padding: 24,
      zIndex: 1000
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxWidth: 360,
      background: 'var(--surface-container-lowest)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--elev-3)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "ditto-headline-md",
    style: {
      margin: 0,
      fontSize: 20,
      color: 'var(--on-surface)'
    }
  }, title), message && /*#__PURE__*/React.createElement("p", {
    className: "ditto-body-md",
    style: {
      margin: '12px 0 0',
      color: 'var(--on-surface-variant)'
    }
  }, message), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 8,
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "text",
    onClick: onCancel
  }, cancelLabel), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: destructive ? 'danger' : 'filled',
    onClick: onConfirm
  }, confirmLabel))));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/forms/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * FilterChip — pill-shaped category filter. Selected chips use the
 * primary-container fill; unselected use a translucent surface.
 */
function Chip({
  children,
  icon,
  selected = false,
  onClick,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 36,
      padding: icon ? '0 14px 0 10px' : '0 16px',
      borderRadius: 'var(--radius-full)',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 'var(--weight-medium)',
      whiteSpace: 'nowrap',
      background: selected ? 'var(--primary-container)' : 'color-mix(in srgb, var(--surface-container-highest) 50%, transparent)',
      color: selected ? 'var(--on-primary-container)' : 'var(--on-surface-variant)',
      transition: 'background var(--dur-fast) var(--ease-standard)',
      ...style
    }
  }, rest), selected && !icon && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 18
    }
  }, "check"), icon && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 18
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Chip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Filled text input. Light-gray fill, hairline border that thickens to
 * 1.5px primary on focus. Supports leading/trailing icons and a label.
 */
function Input({
  label,
  icon,
  trailingIcon,
  onTrailingIconClick,
  error,
  radius = 'sm',
  style = {},
  containerStyle = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const radii = {
    sm: 'var(--radius-sm)',
    md: 'var(--radius-md)'
  };
  const borderColor = error ? 'var(--error)' : focused ? 'var(--primary)' : 'var(--outline-variant)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "ditto-label-md",
    style: {
      color: 'var(--on-surface-variant)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      background: 'var(--surface-container)',
      borderRadius: radii[radius],
      border: `${focused ? '1.5px' : '1px'} solid ${borderColor}`,
      padding: '0 14px',
      height: 48,
      transition: 'border-color var(--dur-fast) var(--ease-standard)'
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 22,
      color: focused ? 'var(--primary)' : 'var(--on-surface-variant)'
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: 16,
      color: 'var(--on-surface)',
      minWidth: 0,
      ...style
    }
  }, rest)), trailingIcon && /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    onClick: onTrailingIconClick,
    style: {
      fontSize: 20,
      color: 'var(--on-surface-variant)',
      cursor: onTrailingIconClick ? 'pointer' : 'default'
    }
  }, trailingIcon)), error && /*#__PURE__*/React.createElement("span", {
    className: "ditto-label-sm",
    style: {
      color: 'var(--error)'
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * DittoBar — the brand's signature pill-shaped search field.
 * Full radius, translucent fill. Optional glass (frosted) treatment
 * for floating over the map / solar background.
 */
function SearchBar({
  placeholder = 'Søk etter tjenester, steder, bedrifter...',
  value,
  onChange,
  glass = false,
  showMic = false,
  onMic,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 52,
      padding: '0 8px 0 16px',
      borderRadius: 'var(--radius-full)',
      background: glass ? 'var(--glass-fill)' : 'color-mix(in srgb, var(--surface-container-highest) 50%, transparent)',
      border: glass ? '1px solid var(--glass-border)' : 'none',
      backdropFilter: glass ? 'blur(var(--blur-glass-strong))' : 'none',
      WebkitBackdropFilter: glass ? 'blur(var(--blur-glass-strong))' : 'none',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 24,
      color: 'var(--primary)'
    }
  }, "search"), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: 16,
      color: 'var(--on-surface)',
      minWidth: 0
    }
  }, rest)), showMic && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onMic,
    style: {
      width: 42,
      height: 42,
      flexShrink: 0,
      border: 'none',
      borderRadius: 'var(--radius-full)',
      background: 'var(--primary)',
      color: 'var(--on-primary)',
      display: 'grid',
      placeItems: 'center',
      cursor: 'pointer',
      boxShadow: 'var(--glow-fab)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 22
    }
  }, "mic")));
}
Object.assign(__ds_scope, { SearchBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchBar.jsx", error: String((e && e.message) || e) }); }

// components/icon/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Material Symbols Rounded glyph. DittoDatto uses the Rounded style
 * (Flutter Icons.*_rounded) throughout.
 */
function Icon({
  name,
  size = 24,
  weight = 400,
  fill = false,
  color = 'currentColor',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "material-symbols-rounded",
    style: {
      fontSize: size,
      lineHeight: 1,
      color,
      fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' ${weight}, 'GRAD' 0, 'opsz' ${size}`,
      userSelect: 'none',
      ...style
    }
  }, rest), name);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icon/Icon.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
const DEFAULT_ITEMS = [{
  key: 'map',
  icon: 'explore',
  label: 'Utforsk'
}, {
  key: 'bookings',
  icon: 'calendar_today',
  label: 'Avtaler'
}, {
  key: 'discovery',
  icon: 'near_me',
  label: 'Oppdage'
}, {
  key: 'profile',
  icon: 'person',
  label: 'Profil'
}];

/**
 * NavBar — glassmorphic bottom navigation. Four contextual icon buttons
 * split around a protruding gradient center FAB. Floats over content
 * (extendBody) with a frosted-glass fill.
 */
function NavBar({
  items = DEFAULT_ITEMS,
  active,
  onSelect,
  fabIcon = 'search',
  onFab,
  style = {}
}) {
  const left = items.slice(0, 2);
  const right = items.slice(2);
  const renderItem = it => {
    const isActive = it.key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      type: "button",
      onClick: () => onSelect && onSelect(it.key),
      style: {
        flex: 1,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        padding: 0,
        color: isActive ? 'var(--primary)' : 'var(--on-surface-variant)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 22,
        fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0"
      }
    }, it.icon), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 9,
        fontWeight: isActive ? 700 : 500,
        letterSpacing: '0.3px',
        fontFamily: 'var(--font-body)'
      }
    }, it.label));
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      padding: '0 16px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 56,
      borderRadius: 'var(--radius-full)',
      background: 'var(--glass-fill)',
      border: '1px solid var(--glass-border)',
      backdropFilter: 'blur(var(--blur-glass-strong))',
      WebkitBackdropFilter: 'blur(var(--blur-glass-strong))',
      display: 'flex',
      alignItems: 'center',
      padding: '0 8px'
    }
  }, left.map(renderItem), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 60,
      flexShrink: 0
    }
  }), right.map(renderItem)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onFab,
    style: {
      position: 'absolute',
      top: -8,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 52,
      height: 52,
      borderRadius: 'var(--radius-full)',
      border: 'none',
      cursor: 'pointer',
      background: 'linear-gradient(135deg, var(--primary-container), var(--primary))',
      color: 'var(--on-primary)',
      display: 'grid',
      placeItems: 'center',
      boxShadow: 'var(--glow-fab)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded",
    style: {
      fontSize: 26
    }
  }, fabIcon)));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the base surface container. 16px padding, 16px radius,
 * hairline border, Level-1 soft shadow. Set `interactive` for hover lift.
 */
function Card({
  children,
  interactive = false,
  padding = 16,
  radius = 'lg',
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const radii = {
    md: 'var(--radius-md)',
    lg: 'var(--radius-lg)',
    xl: 'var(--radius-xl)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      background: 'var(--surface-container-lowest)',
      borderRadius: radii[radius] || radii.lg,
      border: '1px solid color-mix(in srgb, var(--outline-variant) 50%, transparent)',
      padding,
      boxShadow: hover ? 'var(--elev-2)' : 'var(--elev-1)',
      transform: hover ? 'translateY(-2px)' : 'none',
      transition: 'box-shadow var(--dur-normal) var(--ease-standard), transform var(--dur-normal) var(--ease-standard)',
      cursor: interactive ? 'pointer' : 'default',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/GlassPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * GlassPanel — frosted-glass container that floats over the solar
 * background / map. Backdrop blur + translucent fill + hairline border.
 */
function GlassPanel({
  children,
  radius = 'lg',
  blur = 20,
  padding = 16,
  style = {},
  ...rest
}) {
  const radii = {
    md: 'var(--radius-md)',
    lg: 'var(--radius-lg)',
    xl: 'var(--radius-xl)',
    full: 'var(--radius-full)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--glass-fill)',
      borderRadius: radii[radius] || radii.lg,
      border: '1px solid var(--glass-border)',
      backdropFilter: `blur(${blur}px)`,
      WebkitBackdropFilter: `blur(${blur}px)`,
      padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { GlassPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/GlassPanel.jsx", error: String((e && e.message) || e) }); }

// solar/solar-engine.js
try { (() => {
/* ============================================================
   DittoDatto — SolarTheme engine (JS port)
   Faithful port of packages/ditto_design SolarEngine + SunCalc
   (itself a port of the Nuxt useSolarEngine.ts, re-seeded with
   Moody Blue hue 237). Pure functions, no dependencies.

   Maps the REAL-TIME sun position over Drammen, Norway to
   atmospheric HSL + solar phase + star opacity. Because Nordic
   twilight stretches with the seasons, the engine raises a
   dynamic lightness FLOOR in summer so nights never go
   pitch-black — the whole point of the theme.

   Attaches window.DittoSolar = { SunCalc, SolarEngine, PHASES }.
   ============================================================ */
(function () {
  const RAD = Math.PI / 180;
  const DAY_MS = 86400000;
  const J1970 = 2440588;
  const J2000 = 2451545;
  const E = RAD * 23.4397; // obliquity of the Earth

  const SunCalc = {
    _toJulian: date => date.getTime() / DAY_MS - 0.5 + J1970,
    _toDays(date) {
      return this._toJulian(date) - J2000;
    },
    _rightAscension: (l, b) => Math.atan2(Math.sin(l) * Math.cos(E) - Math.tan(b) * Math.sin(E), Math.cos(l)),
    _declination: (l, b) => Math.asin(Math.sin(b) * Math.cos(E) + Math.cos(b) * Math.sin(E) * Math.sin(l)),
    _azimuth: (h, phi, dec) => Math.atan2(Math.sin(h), Math.cos(h) * Math.sin(phi) - Math.tan(dec) * Math.cos(phi)),
    _altitude: (h, phi, dec) => Math.asin(Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(h)),
    _siderealTime: (d, lw) => RAD * (280.16 + 360.9856235 * d) - lw,
    _solarMeanAnomaly: d => RAD * (357.5291 + 0.98560028 * d),
    _eclipticLongitude(m) {
      const c = RAD * (1.9148 * Math.sin(m) + 0.02 * Math.sin(2 * m) + 0.0003 * Math.sin(3 * m));
      const p = RAD * 102.9372;
      return m + c + p + Math.PI;
    },
    /** Returns { altitudeDeg, azimuthDeg } for the given Date at lat/lng. */
    getPosition(date, lat, lng) {
      const lw = RAD * -lng;
      const phi = RAD * lat;
      const d = this._toDays(date);
      const m = this._solarMeanAnomaly(d);
      const l = this._eclipticLongitude(m);
      const dec = this._declination(l, 0);
      const ra = this._rightAscension(l, 0);
      const h = this._siderealTime(d, lw) - ra;
      const altitude = this._altitude(h, phi, dec);
      const azimuth = this._azimuth(h, phi, dec) + Math.PI;
      return {
        altitudeDeg: altitude * 180 / Math.PI,
        azimuthDeg: azimuth * 180 / Math.PI
      };
    }
  };
  const PHASES = {
    day: 'Dag',
    goldenHour: 'Gyllen time',
    civilTwilight: 'Borgerlig skumring',
    nauticalTwilight: 'Nautisk skumring',
    astronomicalTwilight: 'Astronomisk skumring',
    night: 'Natt'
  };
  function clamp(v, a, b) {
    return Math.max(a, Math.min(b, v));
  }
  const SolarEngine = {
    // Drammen, Norway.
    latitude: 59.74,
    longitude: 10.2,
    baseHue: 237,
    // Moody Blue
    baseSaturation: 45,
    /** floor = 5 + clamp((minAlt+18)/18,0,1)*25 */
    lightnessFloor(minAlt) {
      return 5 + clamp((minAlt + 18) / 18, 0, 1) * 25;
    },
    _dayMinAltitude(date) {
      const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      let min = 90;
      for (let h = 0; h < 24; h++) {
        const t = new Date(start.getTime() + h * 3600000);
        const alt = SunCalc.getPosition(t, this.latitude, this.longitude).altitudeDeg;
        if (alt < min) min = alt;
      }
      return min;
    },
    _classifyPhase(alt) {
      if (alt > 8) return 'day';
      if (alt > 0) return 'goldenHour';
      if (alt > -6) return 'civilTwilight';
      if (alt > -12) return 'nauticalTwilight';
      if (alt > -18) return 'astronomicalTwilight';
      return 'night';
    },
    /** Compute the full atmospheric state for a Date (interpreted at Drammen). */
    compute(date) {
      const {
        altitudeDeg,
        azimuthDeg
      } = SunCalc.getPosition(date, this.latitude, this.longitude);
      const minAlt = this._dayMinAltitude(date);
      const floor = this.lightnessFloor(minAlt);

      // Perceptual sigmoid: -20°→floor, 60°→95%, midpoint ~8°.
      const t = clamp((altitudeDeg + 20) / 80, 0, 1);
      const s = 1 / (1 + Math.exp(-10 * (t - 0.35)));
      const range = 95 - floor;
      let lightness = s * range + floor;
      const hue = this.baseHue; // constant — never lerps through green
      let saturation = this.baseSaturation;

      // Warm twilight glow via saturation (not hue) near the horizon.
      if (altitudeDeg >= -2 && altitudeDeg <= 8) {
        const dist = Math.abs(altitudeDeg - 3) / 5;
        const blend = 0.5 * (1 + Math.cos(dist * Math.PI));
        saturation = saturation + (65 - saturation) * blend * 0.5;
      }
      // Nordic Studio damping — desaturate bright daylight.
      if (lightness > 30 && this.baseSaturation > 0) {
        const damp = clamp(1 - (lightness - 30) / 70, 0, 1);
        saturation = clamp(saturation * damp, 5, saturation);
      }
      let starOpacity = 0;
      if (altitudeDeg < -6) starOpacity = clamp((Math.abs(altitudeDeg) - 6) / 12, 0, 1);
      const phase = this._classifyPhase(altitudeDeg);
      return {
        altitude: altitudeDeg,
        azimuth: azimuthDeg,
        lightness,
        hue,
        saturation,
        phase,
        starOpacity,
        minAltitude: minAlt,
        isDark: lightness < 45
      };
    },
    /** Convenience: the two-stop sky gradient CSS for a computed state. */
    skyGradient(st) {
      const top = `hsl(${st.hue}, ${st.saturation}%, ${Math.max(3, st.lightness - 8)}%)`;
      const bottom = `hsl(${st.hue}, ${Math.min(65, st.saturation + 6)}%, ${Math.min(96, st.lightness + 6)}%)`;
      return `linear-gradient(180deg, ${top}, ${bottom})`;
    }
  };
  window.DittoSolar = {
    SunCalc,
    SolarEngine,
    PHASES
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "solar/solar-engine.js", error: String((e && e.message) || e) }); }

// ui_kits/business_portal/app.jsx
try { (() => {
/* DittoDatto Business Portal — admin UI kit.
   Plain Babel script → window.DittoAdminApp. Dark "Midnight Admin" theme.
   Recreates DittoDashboardShell (permanent sidebar) + management screens. */
(function () {
  const NS = window.DittoDattoDesignSystem_1b21a0;
  const {
    Button,
    Badge,
    BOOKING_STATUS,
    Avatar,
    Input,
    EmptyState,
    SearchBar
  } = NS;
  const NAV = [{
    key: 'oversikt',
    icon: 'dashboard',
    label: 'Oversikt'
  }, {
    key: 'bestillinger',
    icon: 'calendar_month',
    label: 'Bestillinger',
    badge: '4'
  }, {
    key: 'etablissement',
    icon: 'storefront',
    label: 'Etablissement'
  }, {
    key: 'tjenester',
    icon: 'content_cut',
    label: 'Tjenester'
  }, {
    key: 'kunder',
    icon: 'group',
    label: 'Kunder'
  }, {
    key: 'innstillinger',
    icon: 'settings',
    label: 'Innstillinger'
  }];
  const KPIS = [{
    label: 'Bestillinger i dag',
    value: '12',
    delta: '+3',
    icon: 'event_available',
    tone: 'primary'
  }, {
    label: 'Omsetning · uke',
    value: '24 850 kr',
    delta: '+8%',
    icon: 'payments',
    tone: 'success'
  }, {
    label: 'Belegg',
    value: '78%',
    delta: '+5%',
    icon: 'donut_large',
    tone: 'primary'
  }, {
    label: 'Nye kunder',
    value: '7',
    delta: '+2',
    icon: 'person_add',
    tone: 'success'
  }];
  const ROWS = [{
    name: 'Kari Nordmann',
    svc: 'Dameklipp',
    time: 'I dag · 10:00',
    staff: 'Ingrid',
    status: 'confirmed'
  }, {
    name: 'Ola Hansen',
    svc: 'Herreklipp',
    time: 'I dag · 11:30',
    staff: 'Ingrid',
    status: 'confirmed'
  }, {
    name: 'Mette Berg',
    svc: 'Skjeggtrim',
    time: 'I dag · 12:15',
    staff: 'Jonas',
    status: 'pending'
  }, {
    name: 'Anders Lie',
    svc: 'Herreklipp + skjegg',
    time: 'I dag · 14:00',
    staff: 'Jonas',
    status: 'confirmed'
  }, {
    name: 'Sofie Dahl',
    svc: 'Dameklipp + farge',
    time: 'I dag · 15:30',
    staff: 'Ingrid',
    status: 'confirmed'
  }, {
    name: 'Per Olsen',
    svc: 'Herreklipp',
    time: 'I går · 16:00',
    staff: 'Jonas',
    status: 'completed'
  }, {
    name: 'Lise Moen',
    svc: 'Dameklipp',
    time: 'I går · 13:00',
    staff: 'Ingrid',
    status: 'noShow'
  }];
  function Sidebar({
    active,
    onSelect
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: 244,
        flexShrink: 0,
        background: 'var(--surface-container-low)',
        borderRight: '1px solid rgba(255,255,255,0.06)',
        display: 'flex',
        flexDirection: 'column',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '20px 18px 16px',
        display: 'flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/logo.png",
      alt: "",
      style: {
        width: 34,
        height: 34,
        flexShrink: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 15,
        color: 'var(--on-surface)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, "Klipp & Stil"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--on-surface-variant)'
      }
    }, "Bedriftsportal"))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        padding: '8px 8px',
        display: 'flex',
        flexDirection: 'column',
        gap: 2,
        overflowY: 'auto'
      }
    }, NAV.map(n => {
      const sel = n.key === active;
      return /*#__PURE__*/React.createElement("button", {
        key: n.key,
        onClick: () => onSelect(n.key),
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '10px 16px',
          border: 'none',
          cursor: 'pointer',
          borderRadius: 'var(--radius-sm)',
          textAlign: 'left',
          width: '100%',
          background: sel ? 'color-mix(in srgb, var(--primary) 15%, transparent)' : 'transparent',
          color: sel ? 'var(--primary)' : 'var(--on-surface-variant)',
          fontFamily: 'var(--font-body)',
          fontSize: 14,
          fontWeight: sel ? 500 : 400,
          transition: 'background var(--dur-fast) var(--ease-standard)'
        }
      }, /*#__PURE__*/React.createElement("span", {
        className: "material-symbols-rounded",
        style: {
          fontSize: 20,
          fontVariationSettings: sel ? "'FILL' 1" : "'FILL' 0"
        }
      }, n.icon), /*#__PURE__*/React.createElement("span", {
        style: {
          flex: 1
        }
      }, n.label), n.badge && /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          fontWeight: 600,
          color: 'var(--primary)',
          background: 'color-mix(in srgb, var(--primary) 15%, transparent)',
          padding: '2px 8px',
          borderRadius: 'var(--radius-md)'
        }
      }, n.badge));
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: '1px solid rgba(255,255,255,0.06)',
        padding: 16,
        display: 'flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: "Ola Nordmann",
      size: 32
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        fontSize: 13,
        color: 'var(--on-surface-variant)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, "Ola Nordmann"), /*#__PURE__*/React.createElement("button", {
      title: "Lyst tema",
      style: iconBtn
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 18
      }
    }, "light_mode")), /*#__PURE__*/React.createElement("button", {
      title: "Logg ut",
      style: iconBtn
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 18
      }
    }, "logout"))));
  }
  const iconBtn = {
    width: 30,
    height: 30,
    border: 'none',
    background: 'transparent',
    color: 'var(--outline)',
    cursor: 'pointer',
    borderRadius: 6,
    display: 'grid',
    placeItems: 'center'
  };
  function Topbar({
    title
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        padding: '18px 28px',
        borderBottom: '1px solid rgba(255,255,255,0.06)'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      className: "ditto-headline-md",
      style: {
        margin: 0,
        fontSize: 22,
        color: 'var(--on-surface)',
        flex: 1
      }
    }, title), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 280
      }
    }, /*#__PURE__*/React.createElement(SearchBar, {
      placeholder: "S\xF8k bestillinger, kunder..."
    })), /*#__PURE__*/React.createElement(Button, {
      icon: "add",
      size: "sm"
    }, "Ny bestilling"));
  }
  function Oversikt() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 28
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: 16,
        marginBottom: 24
      }
    }, KPIS.map(k => /*#__PURE__*/React.createElement("div", {
      key: k.label,
      style: cardStyle
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 40,
        height: 40,
        borderRadius: 'var(--radius-sm)',
        background: `color-mix(in srgb, var(--${k.tone === 'success' ? 'success' : 'primary'}) 14%, transparent)`,
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        color: `var(--${k.tone === 'success' ? 'success' : 'primary'})`
      }
    }, k.icon)), /*#__PURE__*/React.createElement(Badge, {
      tone: k.tone === 'success' ? 'success' : 'primary'
    }, k.delta)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 28,
        color: 'var(--on-surface)',
        marginTop: 14
      }
    }, k.value), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--on-surface-variant)',
        marginTop: 2
      }
    }, k.label)))), /*#__PURE__*/React.createElement("div", {
      style: {
        ...cardStyle,
        padding: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '16px 20px',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        display: 'flex',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      className: "ditto-headline-md",
      style: {
        margin: 0,
        fontSize: 16,
        color: 'var(--on-surface)',
        flex: 1
      }
    }, "Dagens avtaler"), /*#__PURE__*/React.createElement(Button, {
      variant: "text",
      size: "sm",
      trailingIcon: "chevron_right"
    }, "Se alle")), /*#__PURE__*/React.createElement(BookingTable, {
      rows: ROWS.slice(0, 5)
    })));
  }
  function Bestillinger() {
    const [filter, setFilter] = React.useState('alle');
    const filters = [['alle', 'Alle'], ['confirmed', 'Bekreftet'], ['pending', 'Venter'], ['completed', 'Fullført']];
    const rows = filter === 'alle' ? ROWS : ROWS.filter(r => r.status === filter);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 28
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        marginBottom: 16
      }
    }, filters.map(([k, l]) => /*#__PURE__*/React.createElement("button", {
      key: k,
      onClick: () => setFilter(k),
      style: {
        padding: '8px 16px',
        borderRadius: 'var(--radius-full)',
        border: 'none',
        cursor: 'pointer',
        fontSize: 13,
        fontWeight: 500,
        fontFamily: 'var(--font-body)',
        background: filter === k ? 'color-mix(in srgb, var(--primary) 18%, transparent)' : 'var(--surface-container-high)',
        color: filter === k ? 'var(--primary)' : 'var(--on-surface-variant)'
      }
    }, l))), /*#__PURE__*/React.createElement("div", {
      style: {
        ...cardStyle,
        padding: 0
      }
    }, /*#__PURE__*/React.createElement(BookingTable, {
      rows: rows
    }), rows.length === 0 && /*#__PURE__*/React.createElement(EmptyState, {
      title: "Ingen bestillinger",
      message: "Ingen treff for dette filteret."
    })));
  }
  function BookingTable({
    rows
  }) {
    return /*#__PURE__*/React.createElement("table", {
      style: {
        width: '100%',
        borderCollapse: 'collapse',
        fontSize: 14
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        textAlign: 'left',
        color: 'var(--on-surface-variant)',
        fontSize: 12,
        textTransform: 'uppercase',
        letterSpacing: '0.05em'
      }
    }, /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Kunde"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Tjeneste"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Tidspunkt"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Ansatt"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Status"), /*#__PURE__*/React.createElement("th", {
      style: th
    }))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => {
      const s = BOOKING_STATUS[r.status];
      return /*#__PURE__*/React.createElement("tr", {
        key: i,
        style: {
          borderTop: '1px solid rgba(255,255,255,0.05)'
        }
      }, /*#__PURE__*/React.createElement("td", {
        style: td
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }
      }, /*#__PURE__*/React.createElement(Avatar, {
        name: r.name,
        size: 30
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--on-surface)',
          fontWeight: 500
        }
      }, r.name))), /*#__PURE__*/React.createElement("td", {
        style: {
          ...td,
          color: 'var(--on-surface-variant)'
        }
      }, r.svc), /*#__PURE__*/React.createElement("td", {
        style: {
          ...td,
          color: 'var(--on-surface-variant)'
        }
      }, r.time), /*#__PURE__*/React.createElement("td", {
        style: {
          ...td,
          color: 'var(--on-surface-variant)'
        }
      }, r.staff), /*#__PURE__*/React.createElement("td", {
        style: td
      }, /*#__PURE__*/React.createElement(Badge, {
        tone: s.tone,
        icon: s.icon
      }, s.label)), /*#__PURE__*/React.createElement("td", {
        style: {
          ...td,
          textAlign: 'right'
        }
      }, /*#__PURE__*/React.createElement("button", {
        style: iconBtn
      }, /*#__PURE__*/React.createElement("span", {
        className: "material-symbols-rounded",
        style: {
          fontSize: 20
        }
      }, "more_horiz"))));
    })));
  }
  const th = {
    padding: '12px 20px',
    fontWeight: 600
  };
  const td = {
    padding: '12px 20px',
    verticalAlign: 'middle'
  };
  const cardStyle = {
    background: 'var(--surface-container)',
    border: '1px solid rgba(255,255,255,0.06)',
    borderRadius: 'var(--radius-md)',
    padding: 20
  };
  function App() {
    const [active, setActive] = React.useState('oversikt');
    const titles = Object.fromEntries(NAV.map(n => [n.key, n.label]));
    let body;
    if (active === 'oversikt') body = /*#__PURE__*/React.createElement(Oversikt, null);else if (active === 'bestillinger') body = /*#__PURE__*/React.createElement(Bestillinger, null);else body = /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 28
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: cardStyle
    }, /*#__PURE__*/React.createElement(EmptyState, {
      icon: "construction",
      title: "Kommer snart",
      message: "Denne seksjonen er under utvikling."
    })));
    return /*#__PURE__*/React.createElement("div", {
      "data-theme": "dark",
      style: {
        position: 'absolute',
        inset: 0,
        display: 'flex',
        background: 'var(--surface)',
        color: 'var(--on-surface)',
        fontFamily: 'var(--font-body)'
      }
    }, /*#__PURE__*/React.createElement(Sidebar, {
      active: active,
      onSelect: setActive
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement(Topbar, {
      title: titles[active]
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto'
      }
    }, body)));
  }
  window.DittoAdminApp = App;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/business_portal/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/consumer_app/app.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* DittoDatto Consumer App — UI kit screens.
   Plain Babel script (no ES modules): defines the app and attaches it to
   window.DittoConsumerApp. Composes primitives from the DS bundle namespace. */
(function () {
  const NS = window.DittoDattoDesignSystem_1b21a0;
  const {
    SearchBar,
    Chip,
    ListingCard,
    NavBar,
    Badge,
    BOOKING_STATUS,
    Avatar,
    Button,
    Input,
    EmptyState,
    GlassPanel
  } = NS;
  const CATEGORIES = [{
    slug: 'alle',
    name: 'Alle',
    icon: null
  }, {
    slug: 'fri',
    name: 'Frisør',
    icon: 'content_cut'
  }, {
    slug: 'rest',
    name: 'Restaurant',
    icon: 'restaurant'
  }, {
    slug: 'spa',
    name: 'Velvære',
    icon: 'spa'
  }, {
    slug: 'tren',
    name: 'Trening',
    icon: 'fitness_center'
  }, {
    slug: 'helse',
    name: 'Helse',
    icon: 'local_hospital'
  }];
  const LISTINGS = [{
    id: 'klipp',
    name: 'Klipp & Stil',
    cat: 'fri',
    category: 'Frisør',
    cover: 'https://picsum.photos/seed/ditto-hair/480/270',
    rating: {
      average: 4.8,
      count: 126
    },
    address: 'Storgata 12',
    city: 'Drammen',
    open: true,
    services: [{
      t: 'Herreklipp',
      d: '30 min',
      p: '349 kr'
    }, {
      t: 'Dameklipp',
      d: '45 min',
      p: '549 kr'
    }, {
      t: 'Skjeggtrim',
      d: '15 min',
      p: '199 kr'
    }]
  }, {
    id: 'brygg',
    name: 'Bryggeriet Mat & Vin',
    cat: 'rest',
    category: 'Restaurant',
    cover: 'https://picsum.photos/seed/ditto-food/480/270',
    rating: {
      average: 4.6,
      count: 208
    },
    address: 'Havnegata 4',
    city: 'Drammen',
    open: true,
    services: [{
      t: 'Bord for 2',
      d: '2 timer',
      p: 'Gratis'
    }, {
      t: 'Bord for 4',
      d: '2 timer',
      p: 'Gratis'
    }, {
      t: 'Chef’s table',
      d: '3 timer',
      p: '1 290 kr'
    }]
  }, {
    id: 'spa',
    name: 'Nordic Spa & Velvære',
    cat: 'spa',
    category: 'Velvære',
    cover: 'https://picsum.photos/seed/ditto-spa/480/270',
    rating: {
      average: 4.9,
      count: 54
    },
    address: 'Bragernes torg 7',
    city: 'Drammen',
    open: false,
    services: [{
      t: 'Klassisk massasje',
      d: '60 min',
      p: '899 kr'
    }, {
      t: 'Ansiktsbehandling',
      d: '50 min',
      p: '749 kr'
    }]
  }, {
    id: 'cross',
    name: 'CrossFit Elvebyen',
    cat: 'tren',
    category: 'Trening',
    cover: 'https://picsum.photos/seed/ditto-gym/480/270',
    rating: {
      average: 4.7,
      count: 89
    },
    address: 'Grønland 30',
    city: 'Drammen',
    open: true,
    services: [{
      t: 'Drop-in økt',
      d: '60 min',
      p: '199 kr'
    }, {
      t: 'PT-time',
      d: '45 min',
      p: '649 kr'
    }]
  }, {
    id: 'tann',
    name: 'Tannlege Solberg',
    cat: 'helse',
    category: 'Helse',
    cover: 'https://picsum.photos/seed/ditto-dental/480/270',
    rating: {
      average: 4.5,
      count: 61
    },
    address: 'Engene 18',
    city: 'Drammen',
    open: true,
    services: [{
      t: 'Undersøkelse',
      d: '30 min',
      p: '690 kr'
    }, {
      t: 'Tannrens',
      d: '45 min',
      p: '890 kr'
    }]
  }];
  const DAYS = ['Man', 'Tir', 'Ons', 'Tor', 'Fre', 'Lør', 'Søn'];
  const MONTHS = ['jan', 'feb', 'mar', 'apr', 'mai', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'des'];
  function fmtDate(d) {
    return `${DAYS[(d.getDay() + 6) % 7]} ${d.getDate()}. ${MONTHS[d.getMonth()]} · ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  // ── Discovery / Home ──────────────────────────────────────────────
  function Discovery({
    onOpen,
    query,
    setQuery,
    cat,
    setCat
  }) {
    const list = LISTINGS.filter(l => {
      const okCat = cat === 'alle' || l.cat === cat;
      const okQ = !query || (l.name + l.category + l.city).toLowerCase().includes(query.toLowerCase());
      return okCat && okQ;
    });
    return /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: 96
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '8px 16px 4px',
        position: 'sticky',
        top: 0,
        background: 'var(--scaffold)',
        zIndex: 5
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        margin: '4px 0 10px'
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/logo.png",
      alt: "",
      style: {
        width: 26,
        height: 26
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "ditto-headline-lg",
      style: {
        fontSize: 26,
        color: 'var(--primary)',
        fontWeight: 800
      }
    }, "DittoDatto")), /*#__PURE__*/React.createElement(SearchBar, {
      value: query,
      onChange: e => setQuery(e.target.value)
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        overflowX: 'auto',
        padding: '10px 16px',
        scrollbarWidth: 'none'
      }
    }, CATEGORIES.map(c => /*#__PURE__*/React.createElement(Chip, {
      key: c.slug,
      icon: c.icon,
      selected: cat === c.slug,
      onClick: () => setCat(c.slug)
    }, c.name))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        padding: '4px 16px 0'
      }
    }, list.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
      icon: "search_off",
      title: "Ingen resultater",
      message: "Pr\xF8v et annet s\xF8keord."
    }) : list.map(l => /*#__PURE__*/React.createElement(ListingCard, _extends({
      key: l.id
    }, l, {
      onClick: () => onOpen(l)
    })))));
  }

  // ── Establishment detail sheet ────────────────────────────────────
  function Detail({
    listing,
    onClose,
    onBook
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'var(--scaffold)',
        zIndex: 40,
        display: 'flex',
        flexDirection: 'column',
        animation: 'ditto-slide-up .28s var(--ease-decelerate)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        height: 200,
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: listing.cover,
      alt: "",
      style: {
        width: '100%',
        height: '100%',
        objectFit: 'cover'
      }
    }), /*#__PURE__*/React.createElement("button", {
      onClick: onClose,
      style: {
        position: 'absolute',
        top: 16,
        left: 16,
        width: 40,
        height: 40,
        borderRadius: '50%',
        border: 'none',
        background: 'var(--glass-fill)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        display: 'grid',
        placeItems: 'center',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "arrow_back"))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '20px 20px 32px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      className: "ditto-headline-lg",
      style: {
        margin: 0,
        fontSize: 24
      }
    }, listing.name), /*#__PURE__*/React.createElement(Badge, {
      tone: listing.open ? 'success' : 'neutral'
    }, listing.open ? 'Åpent nå' : 'Stengt')), /*#__PURE__*/React.createElement("p", {
      className: "ditto-body-md",
      style: {
        color: 'var(--on-surface-variant)',
        margin: '6px 0 0'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 16,
        verticalAlign: '-3px'
      }
    }, "location_on"), " ", listing.address, ", ", listing.city, " \xB7 \u2605 ", listing.rating.average), /*#__PURE__*/React.createElement("h3", {
      className: "ditto-headline-md",
      style: {
        fontSize: 17,
        margin: '24px 0 12px'
      }
    }, "Tjenester"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, listing.services.map((s, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '14px 16px',
        background: 'var(--surface-container-lowest)',
        border: '1px solid color-mix(in srgb, var(--outline-variant) 50%, transparent)',
        borderRadius: 'var(--radius-md)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 15
      }
    }, s.t), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--on-surface-variant)'
      }
    }, s.d, " \xB7 ", s.p)), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => onBook(listing, s)
    }, "Bestill"))))));
  }

  // ── Bookings ──────────────────────────────────────────────────────
  function Bookings({
    authed,
    bookings,
    onLogin
  }) {
    if (!authed) {
      return /*#__PURE__*/React.createElement("div", {
        style: {
          padding: '80px 24px',
          display: 'grid',
          placeItems: 'center',
          minHeight: '70%'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          textAlign: 'center',
          maxWidth: 300
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          width: 80,
          height: 80,
          margin: '0 auto 20px',
          borderRadius: '50%',
          background: 'color-mix(in srgb, var(--primary) 14%, transparent)',
          display: 'grid',
          placeItems: 'center'
        }
      }, /*#__PURE__*/React.createElement("span", {
        className: "material-symbols-rounded",
        style: {
          fontSize: 36,
          color: 'var(--primary)'
        }
      }, "lock")), /*#__PURE__*/React.createElement("h2", {
        className: "ditto-headline-md",
        style: {
          fontSize: 20,
          margin: '0 0 8px'
        }
      }, "Krever innlogging"), /*#__PURE__*/React.createElement("p", {
        className: "ditto-body-md",
        style: {
          fontSize: 14,
          color: 'var(--on-surface-variant)',
          margin: '0 0 20px'
        }
      }, "Logg inn for \xE5 se bestillinger, administrere avtaler og se historikk."), /*#__PURE__*/React.createElement(Button, {
        fullWidth: true,
        trailingIcon: "arrow_forward",
        onClick: onLogin
      }, "Logg inn")));
    }
    const upcoming = bookings.filter(b => b.when > Date.now());
    const past = bookings.filter(b => b.when <= Date.now());
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '24px 16px 96px'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      className: "ditto-headline-lg",
      style: {
        fontSize: 24,
        fontWeight: 800,
        margin: '0 0 20px'
      }
    }, "Mine bestillinger"), bookings.length === 0 && /*#__PURE__*/React.createElement(EmptyState, {
      icon: "calendar_month",
      title: "Ingen bestillinger enn\xE5",
      message: "Utforsk v\xE5re tjenester for \xE5 finne din neste time."
    }), upcoming.length > 0 && /*#__PURE__*/React.createElement(SectionLabel, null, "Kommende"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        marginBottom: 24
      }
    }, upcoming.map(b => /*#__PURE__*/React.createElement(UpcomingCard, {
      key: b.id,
      b: b
    }))), past.length > 0 && /*#__PURE__*/React.createElement(SectionLabel, null, "Tidligere"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }
    }, past.map(b => /*#__PURE__*/React.createElement(PastCard, {
      key: b.id,
      b: b
    }))));
  }
  function SectionLabel({
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        letterSpacing: '0.8px',
        color: 'var(--on-surface-variant)',
        margin: '0 0 12px'
      }
    }, children);
  }
  function UpcomingCard({
    b
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--surface-container-lowest)',
        border: '1px solid color-mix(in srgb, var(--outline-variant) 50%, transparent)',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        boxShadow: 'var(--elev-1)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 3,
        background: 'linear-gradient(90deg, var(--primary), color-mix(in srgb, var(--primary) 40%, transparent))'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 16
      }
    }, b.est), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--on-surface-variant)'
      }
    }, b.svc)), /*#__PURE__*/React.createElement(Badge, {
      tone: BOOKING_STATUS.confirmed.tone,
      icon: BOOKING_STATUS.confirmed.icon
    }, BOOKING_STATUS.confirmed.label)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 12,
        padding: '8px 12px',
        background: 'color-mix(in srgb, var(--on-surface) 5%, transparent)',
        borderRadius: 'var(--radius-sm)',
        fontSize: 13,
        color: 'var(--on-surface-variant)',
        fontWeight: 500
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 16,
        color: 'var(--primary)'
      }
    }, "calendar_month"), fmtDate(new Date(b.when))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        marginTop: 12
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "outlined",
      size: "sm",
      style: {
        flex: 1
      }
    }, "Endre tid"), /*#__PURE__*/React.createElement(Button, {
      variant: "outlined",
      size: "sm",
      style: {
        flex: 1,
        color: 'var(--error)',
        borderColor: 'color-mix(in srgb, var(--error) 30%, transparent)'
      }
    }, "Avbestill"))));
  }
  function PastCard({
    b
  }) {
    const s = BOOKING_STATUS.completed;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '12px 16px',
        background: 'var(--surface-container-lowest)',
        border: '1px solid color-mix(in srgb, var(--outline-variant) 40%, transparent)',
        borderRadius: 'var(--radius-md)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 44,
        height: 44,
        borderRadius: 'var(--radius-sm)',
        background: 'color-mix(in srgb, var(--success) 12%, transparent)',
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        color: 'var(--success)'
      }
    }, "check_circle")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 14
      }
    }, b.est), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--on-surface-variant)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, b.svc, " \xB7 ", fmtDate(new Date(b.when)))), /*#__PURE__*/React.createElement(Badge, {
      tone: s.tone,
      icon: s.icon
    }, s.label));
  }

  // ── Profile / inline auth ─────────────────────────────────────────
  function Profile({
    authed,
    name,
    onLogin,
    onLogout
  }) {
    if (!authed) return /*#__PURE__*/React.createElement(InlineAuth, {
      onLogin: onLogin
    });
    const first = (name || 'der').split(' ')[0];
    const now = new Date();
    const dateStr = `${['søndag', 'mandag', 'tirsdag', 'onsdag', 'torsdag', 'fredag', 'lørdag'][now.getDay()]} ${now.getDate()}. ${MONTHS[now.getMonth()]} ${now.getFullYear()}`;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '40px 24px 96px',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: name,
      size: 96,
      style: {
        margin: '0 auto'
      }
    }), /*#__PURE__*/React.createElement("h1", {
      className: "ditto-headline-lg",
      style: {
        fontSize: 24,
        margin: '20px 0 4px'
      }
    }, "Hei, ", first, " \uD83D\uDC4B"), /*#__PURE__*/React.createElement("p", {
      className: "ditto-body-md",
      style: {
        color: 'var(--on-surface-variant)',
        margin: 0
      }
    }, "I dag er ", dateStr), /*#__PURE__*/React.createElement("p", {
      className: "ditto-body-md",
      style: {
        color: 'var(--on-surface-variant)',
        fontSize: 14,
        margin: '4px 0 0'
      }
    }, "kari@epost.no"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 28,
        textAlign: 'left'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        padding: '16px 20px',
        background: 'var(--surface-container-low)',
        border: '1px solid color-mix(in srgb, var(--outline-variant) 50%, transparent)',
        borderRadius: 'var(--radius-lg)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 44,
        height: 44,
        borderRadius: '50%',
        background: 'color-mix(in srgb, var(--error) 12%, transparent)',
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        color: 'var(--error)',
        fontVariationSettings: "'FILL' 1"
      }
    }, "favorite")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 15
      }
    }, "Mine favoritter"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--on-surface-variant)'
      }
    }, "3 lagrede steder")), /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        color: 'var(--on-surface-variant)'
      }
    }, "chevron_right"))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 24
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "outlined",
      icon: "logout",
      fullWidth: true,
      onClick: onLogout
    }, "Logg ut")));
  }
  function InlineAuth({
    onLogin
  }) {
    const [signup, setSignup] = React.useState(false);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '40px 24px 96px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        marginBottom: 28
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/logo.png",
      alt: "",
      style: {
        width: 60,
        height: 60
      }
    }), /*#__PURE__*/React.createElement("h1", {
      className: "ditto-headline-lg",
      style: {
        fontSize: 24,
        margin: '12px 0 4px'
      }
    }, signup ? 'Opprett konto' : 'Logg inn'), /*#__PURE__*/React.createElement("p", {
      className: "ditto-body-md",
      style: {
        fontSize: 14,
        color: 'var(--on-surface-variant)',
        margin: 0
      }
    }, signup ? 'Kom i gang med DittoDatto' : 'Logg inn for å se profil, bestillinger og favoritter')), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16
      }
    }, signup && /*#__PURE__*/React.createElement(Input, {
      label: "Fullt navn",
      icon: "person",
      defaultValue: "Kari Nordmann",
      radius: "md"
    }), /*#__PURE__*/React.createElement(Input, {
      label: "E-post",
      icon: "mail",
      defaultValue: "kari@epost.no",
      radius: "md"
    }), /*#__PURE__*/React.createElement(Input, {
      label: "Passord",
      icon: "lock",
      trailingIcon: "visibility",
      type: "password",
      defaultValue: "hemmelig",
      radius: "md"
    }), /*#__PURE__*/React.createElement(Button, {
      fullWidth: true,
      trailingIcon: "arrow_forward",
      onClick: onLogin,
      style: {
        marginTop: 4
      }
    }, signup ? 'Opprett konto' : 'Logg inn'), /*#__PURE__*/React.createElement(Button, {
      variant: "text",
      onClick: () => setSignup(!signup)
    }, signup ? 'Har du allerede konto? Logg inn' : 'Har du ikke en konto? Registrer deg')));
  }

  // ── Search overlay (FAB) ──────────────────────────────────────────
  function SearchOverlay({
    onClose,
    onOpen
  }) {
    const [q, setQ] = React.useState('');
    const results = q ? LISTINGS.filter(l => (l.name + l.category).toLowerCase().includes(q.toLowerCase())) : [];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        zIndex: 50,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'flex-end',
        background: 'linear-gradient(160deg, #141a4d, #3f51b5 60%, #b40050)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        padding: 16,
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        justifyContent: 'flex-end'
      }
    }, results.map(l => /*#__PURE__*/React.createElement(ListingCard, _extends({
      key: l.id
    }, l, {
      onClick: () => onOpen(l)
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 12,
        display: 'flex',
        gap: 8,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: onClose,
      style: {
        width: 44,
        height: 44,
        borderRadius: '50%',
        border: '1px solid var(--glass-border)',
        background: 'var(--glass-fill)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        display: 'grid',
        placeItems: 'center',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "arrow_back")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement(SearchBar, {
      glass: true,
      showMic: true,
      value: q,
      onChange: e => setQ(e.target.value),
      placeholder: "S\xF8k etter..."
    }))));
  }

  // ── App shell ─────────────────────────────────────────────────────
  // ── Theme (SolarTheme aware) ──────────────────────────────────────
  function effectiveDark(theme, solarHour) {
    if (theme === 'dark') return true;
    if (theme === 'light') return false;
    const d = new Date();
    d.setHours(solarHour, 0, 0, 0);
    return window.DittoSolar ? window.DittoSolar.SolarEngine.compute(d).isDark : false;
  }
  function TweaksPanel({
    theme,
    setTheme,
    solarHour,
    setSolarHour,
    phaseLabel
  }) {
    const [open, setOpen] = React.useState(false);
    React.useEffect(() => {
      const onMsg = e => {
        const t = e.data && e.data.type;
        if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
      };
      window.addEventListener('message', onMsg);
      window.parent.postMessage({
        type: '__edit_mode_available'
      }, '*');
      return () => window.removeEventListener('message', onMsg);
    }, []);
    if (!open) return null;
    const seg = (val, label) => /*#__PURE__*/React.createElement("button", {
      onClick: () => setTheme(val),
      style: {
        flex: 1,
        border: 'none',
        cursor: 'pointer',
        padding: '7px 4px',
        borderRadius: 'var(--radius-full)',
        fontFamily: 'var(--font-body)',
        fontSize: 12,
        fontWeight: 500,
        background: theme === val ? 'var(--surface-container-lowest)' : 'transparent',
        color: theme === val ? 'var(--primary)' : 'var(--on-surface-variant)',
        boxShadow: theme === val ? 'var(--elev-1)' : 'none'
      }
    }, label);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 52,
        left: 16,
        right: 16,
        zIndex: 80,
        background: 'var(--surface-container-lowest)',
        border: '1px solid var(--outline-variant)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--elev-3)',
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement("h3", {
      style: {
        margin: 0,
        flex: 1,
        fontFamily: 'var(--font-display)',
        fontSize: 15,
        fontWeight: 700,
        color: 'var(--on-surface)'
      }
    }, "Tweaks"), /*#__PURE__*/React.createElement("button", {
      onClick: () => {
        setOpen(false);
        window.parent.postMessage({
          type: '__edit_mode_dismissed'
        }, '*');
      },
      style: {
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        color: 'var(--on-surface-variant)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded",
      style: {
        fontSize: 20
      }
    }, "close"))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--on-surface-variant)',
        marginBottom: 6
      }
    }, "Tema"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 4,
        background: 'var(--surface-container-high)',
        padding: 3,
        borderRadius: 'var(--radius-full)'
      }
    }, seg('auto', 'Auto (sol)'), seg('light', 'Lys'), seg('dark', 'Mørk')), theme === 'auto' && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        fontSize: 12,
        color: 'var(--on-surface-variant)',
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("span", null, "Sol-tid \xB7 Drammen"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        color: 'var(--primary)'
      }
    }, String(solarHour).padStart(2, '0'), ":00 \xB7 ", phaseLabel)), /*#__PURE__*/React.createElement("input", {
      type: "range",
      min: "0",
      max: "23",
      value: solarHour,
      onChange: e => setSolarHour(+e.target.value),
      style: {
        width: '100%',
        accentColor: 'var(--primary)'
      }
    })));
  }
  function App() {
    const [tab, setTab] = React.useState('map');
    const [query, setQuery] = React.useState('');
    const [cat, setCat] = React.useState('alle');
    const [authed, setAuthed] = React.useState(false);
    const [detail, setDetail] = React.useState(null);
    const [search, setSearch] = React.useState(false);
    const T = window.__dittoTweaks || {
      theme: 'auto',
      solarHour: new Date().getHours()
    };
    const [theme, setThemeState] = React.useState(T.theme);
    const [solarHour, setSolarHourState] = React.useState(T.solarHour);
    const persist = edits => window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    const setTheme = v => {
      setThemeState(v);
      persist({
        theme: v
      });
    };
    const setSolarHour = v => {
      setSolarHourState(v);
      persist({
        solarHour: v
      });
    };
    const dark = effectiveDark(theme, solarHour);
    const solarState = window.DittoSolar ? (() => {
      const d = new Date();
      d.setHours(solarHour, 0, 0, 0);
      return window.DittoSolar.SolarEngine.compute(d);
    })() : null;
    const phaseLabel = solarState ? window.DittoSolar.PHASES[solarState.phase] : '';
    React.useEffect(() => {
      document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    }, [dark]);
    const [bookings, setBookings] = React.useState([{
      id: 'b0',
      est: 'Nordic Spa & Velvære',
      svc: 'Klassisk massasje',
      when: Date.now() - 86400000 * 6
    }]);
    const [toast, setToast] = React.useState(null);
    function book(listing, svc) {
      const when = Date.now() + 86400000 * 2 + 3600000 * 10;
      setBookings(bs => [{
        id: 'b' + Date.now(),
        est: listing.name,
        svc: svc.t,
        when
      }, ...bs]);
      setDetail(null);
      if (!authed) setAuthed(true);
      setToast('Timen er bekreftet ✓');
      setTimeout(() => setToast(null), 2600);
    }
    let screen;
    if (tab === 'map') screen = /*#__PURE__*/React.createElement(Discovery, {
      onOpen: setDetail,
      query: query,
      setQuery: setQuery,
      cat: cat,
      setCat: setCat
    });else if (tab === 'bookings') screen = /*#__PURE__*/React.createElement(Bookings, {
      authed: authed,
      bookings: bookings,
      onLogin: () => setTab('profile')
    });else screen = /*#__PURE__*/React.createElement(Profile, {
      authed: authed,
      name: "Kari Nordmann",
      onLogin: () => setAuthed(true),
      onLogout: () => setAuthed(false)
    });
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'var(--scaffold)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        overflowY: 'auto'
      }
    }, screen), /*#__PURE__*/React.createElement(TweaksPanel, {
      theme: theme,
      setTheme: setTheme,
      solarHour: solarHour,
      setSolarHour: setSolarHour,
      phaseLabel: phaseLabel
    }), detail && /*#__PURE__*/React.createElement(Detail, {
      listing: detail,
      onClose: () => setDetail(null),
      onBook: book
    }), search && /*#__PURE__*/React.createElement(SearchOverlay, {
      onClose: () => setSearch(false),
      onOpen: l => {
        setSearch(false);
        setDetail(l);
      }
    }), toast && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        bottom: 96,
        left: 16,
        right: 16,
        zIndex: 60,
        background: 'var(--inverse-surface)',
        color: 'var(--inverse-on-surface)',
        padding: '14px 18px',
        borderRadius: 'var(--radius-sm)',
        fontSize: 14,
        fontWeight: 500,
        boxShadow: 'var(--elev-2)',
        animation: 'ditto-slide-up .28s var(--ease-decelerate)'
      }
    }, toast), !detail && !search && /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 12
      }
    }, /*#__PURE__*/React.createElement(NavBar, {
      active: tab,
      onSelect: setTab,
      fabIcon: "search",
      onFab: () => setSearch(true)
    })));
  }
  window.DittoConsumerApp = App;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/consumer_app/app.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.BOOKING_STATUS = __ds_scope.BOOKING_STATUS;

__ds_ns.ListingCard = __ds_scope.ListingCard;

__ds_ns.RatingBadge = __ds_scope.RatingBadge;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SearchBar = __ds_scope.SearchBar;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.NavBar = __ds_scope.NavBar;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.GlassPanel = __ds_scope.GlassPanel;

})();
