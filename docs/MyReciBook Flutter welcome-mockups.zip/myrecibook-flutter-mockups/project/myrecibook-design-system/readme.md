# MyReciBook Design System

The design system for **MyReciBook** — a pay-once Android recipe app that
rescues recipes out of screenshots, links and handwritten cards into plain
files the user owns. No subscription, no account, no server. AI extraction is
metered by a yearly fair-use cap; typing recipes in is always unlimited.

> **Positioning in one line:** "Pay once. Cook forever." — your recipe box
> shouldn't have a landlord.

## Product

One product: the **Android app** (Flutter). Core surfaces, all mocked light +
dark: cookbook home, recipe detail, cook mode, import sheet (screenshots /
link / camera / manual), extraction review, batch queue, manual entry, grocery
list, paywall, storage setup & manage, settings, restore ("New phone"),
"Your copy" dashboard, navigation drawer.

## Sources this system was built from

- **`MyReciBook Mockups.dc.html`** (this project) — the mockup canvas, turns
  1–6, the single source of truth for every value here. Turn 6 reconciled the
  design against the running alpha (commit 475b67b), so these patterns match
  built code.
- **DittoDatto Design System** (project id
  `1b21a094-c998-4aa1-ae4b-107c0dfe5a0c`) — the M3 token foundation the
  mockups were designed on. Tokens are inherited verbatim (same names, same
  values) so existing mockup markup transfers 1:1; MyReciBook does **not**
  inherit DittoDatto's brand assets, Norwegian copy, SolarTheme, or
  marketplace components.

## CONTENT FUNDAMENTALS

**Language.** English. Short sentences, plain words, addressed as "you/your".

**Voice.** Calm, honest, ownership-obsessed. The app never overclaims, never
blames, and states reassurances explicitly. Untrue claims are treated as
high-severity bugs (e.g. the drawer drops its "owned" tag until the Play
receipt makes it true).

**Verbatim tone examples (use these as calibration):**
- Paywall: *"Pay once. Cook forever."* / *"No subscription. No account. Ever."*
- Anti-subscription expander: *"Because your recipe box shouldn't have a
  landlord. You buy MyReciBook like you'd buy a good knife: once."*
- Extraction failure: *"That one kept its secrets"* — then the three
  reassurances: gallery untouched, nothing deleted, cap unspent.
- Queue captions: *"saved · looked complete"* (auto) vs *"saved · you checked
  it"* (hand-reviewed) — the caption tells the truth about who checked.
- Skipped item: *"Not a recipe — skipped, nothing saved"*.
- Manual-entry door: *"Type it in yourself"* / *"no AI, no cap — always
  unlimited"*.
- Storage: *"Move, export or leave anytime. If MyReciBook vanished tomorrow,
  your recipes wouldn't."*
- Exit framing: *"Nothing to sign out of, no account to delete. Leaving =
  keeping your files."*

**Casing.** Sentence case everywhere (buttons, titles, rows). ALL-CAPS only
for the 11px tracked-out section eyebrows ("INGREDIENTS · 8", "UNDER THE
HOOD"). Sub-captions under row titles are lowercase fragments ("zero setup ·
works offline").

**Punctuation habits.** Middots join metadata ("25 min · 4 servings");
em-dashes carry the honest aside ("one tap, no password"); counts are stated
plainly ("2 saved · 1 failed · 1 skipped"). Numbers in running text use
digits.

**Emoji.** Never. Material Symbols Rounded carries all iconography.

**Destructive confirms.** Say what survives before what stops ("Nothing is
deleted. Your recipes stay… — they just stop syncing."), confirm button
repeats the verb ("Disconnect"), Cancel is the safe default.

## VISUAL FOUNDATIONS

**Color.** M3 tonal palettes from the Moody Blue seed `#3F51B5`. Primary
`#24389c` carries brand moments (wordmark, filled buttons, progress, active
states); secondary-container tints chips, tonal buttons and placeholder art;
tertiary magenta is rare (ONE-TIME price tag, favorite heart). Status colors
are theme-stable (`--success #22c55e`, `--warning #f59e0b`, `--error` M3 red).
See `tokens/colors.css`.

**Two themes.** Light: warm cream scaffold `#faf8f0` with white cards — the
default. Dark: deep navy (`#0f1117` scaffold, `#0a0c11` cards), never pure
black. Every screen ships in both; toggle via `[data-theme="dark"]`.

**Type.** Plus Jakarta Sans (700/800, tight tracking) for display, headlines,
screen titles, recipe titles and the wordmark; Inter for everything else.
Cook mode runs large (26–27px steps). Mono (ui-monospace) marks "techy edge"
moments: file paths, install_id, meter counts like `245 / 600`.

**Spacing & layout.** 4px rhythm; screens pad 20px at the sides; stacked
content gap is 12px; recipe grid is 2-up with 12px gutters. Phones are 360px
wide in mockups.

**Shape.** 8px buttons/thumbs, 12px row cards & tiles, 16px feature cards,
24px sheets & dialogs, full pills for chips/search/meta pills/stadium CTAs/
drawer rows. Bottom sheets round the top corners only.

**Cards.** White (surface-container-lowest) fill, hairline border
(`--hairline`), radius 12–16px, soft indigo Level-1 shadow. Selected/active
cards switch to a 1.5px primary border + `--glow-primary`; flagged cards use
the same pattern in `--warning` (needs review) or `--error` (failed); dimmed
states drop to ~60% opacity (skipped items, awaiting-keys card).

**Elevation.** Indigo-tinted ambient shadows (L1/L2/L3); dark mode leans on
lighter navy surfaces and plain black shadows. Bottom sheets and the drawer
sit at L3 over a 45% dark scrim (`#0b0d16` at 45%).

**Glass.** Reserved for chrome floating over imagery: the bottom NavBar and
circular icon buttons over recipe covers (blur 12–24px, translucent fill,
hairline border).

**Backgrounds & imagery.** Flat token surfaces; no gradients except the
NavBar FAB (135° primary-container→primary). Recipe covers are the user's own
screenshots — in mockups/empty states use `--placeholder-stripes` (45° indigo
stripes) with a tiny mono tag ("your screenshot"). Never stock photography.

**Borders.** Hairlines everywhere (`--hairline` = outline-variant at 50%);
in-card row dividers use `--hairline-soft` (35%). Dashed 1px borders mark two
things: reassurance notes and empty/add affordances ("+ tag", "+ time").

**Motion.** Purposeful, never bouncy: 150/300/500ms with M3 emphasized easing
`cubic-bezier(0.2,0,0,1)`. Hover = 2px card lift to L2 (pointer contexts);
press = tonal darkening/ripple. Respect `prefers-reduced-motion`.

**Signature motifs.** Stadium (full-pill) primary CTA pinned to the screen
bottom; 11px tracked eyebrows labelling every content group; icon-in-a-
rounded-square leading slots (40×40, radius 12) on row cards; dashed
reassurance notes; the mono "under the hood" block; segmented pill toggles;
progress meters with honest mono counts.

## ICONOGRAPHY

**One system: Material Symbols Rounded** (Google Fonts, loaded by
`tokens/fonts.css`). No custom SVGs, no emoji, no second icon set. Filled
axis (`'FILL' 1`) marks active/selected/success states (active nav item,
favorite heart, success check_circle, the wordmark's menu_book).

Common glyphs in use: `menu_book`, `checklist`, `calendar_month`, `settings`,
`download`, `add`, `edit`, `photo_camera`, `link`, `search`, `favorite`,
`schedule`, `restaurant`, `timer`, `check`, `check_circle`, `cloud_done`,
`cloud_sync`, `add_to_drive`, `phone_android`, `receipt_long`, `verified`,
`folder_zip`, `refresh`, `swap_horiz`, `arrow_back`, `arrow_forward`,
`chevron_right`, `close`, `menu`, `hourglass_top`, `no_meals`, `auto_delete`,
`ios_share`, `event_repeat`, `push_pin`, `help`, `description`, `info`.

**Logo.** There is **no drawn logo asset**. The brand mark is typographic:
the filled `menu_book` glyph in primary + the wordmark "MyReciBook" in Plus
Jakarta Sans 800, −0.02em, primary color (`.mrb-wordmark`). Do not invent a
logo.

## Components (`components/`)

The inventory is exactly what the mockups use — nothing speculative.

- **icon/** — `Icon` (Material Symbols Rounded wrapper)
- **forms/** — `Button` (filled · tonal · outlined · text · danger; sm/md;
  icons; fullWidth), `Chip` (filter pill), `SearchBar` (pill search),
  `SegmentedControl` (import-mode toggle, theme picker)
- **data-display/** — `Badge` (Synced/Owned status pill), `RecipeCard`
  (cookbook grid tile), `RowCard` (the workhorse icon/thumb+title+sub+trailing
  row: storage cards, import doors, queue items, restore steps), `Meter`
  (fair-use rescue meter), `SectionLabel` (tracked eyebrow), `Note` (dashed
  reassurance box)
- **feedback/** — `EmptyState`, `Dialog` (destructive-capable confirm;
  `contained` prop keeps it inside a phone frame)
- **navigation/** — `NavBar` (glass bottom nav + center FAB; default items
  Cookbook/Grocery/Plan/Settings)

**Intentional additions** (patterns lifted from repeated mockup markup rather
than a component library): `SegmentedControl`, `RecipeCard`, `RowCard`,
`Meter`, `SectionLabel`, `Note`, and Dialog's `contained` prop — each exists
because the pattern recurs across ≥3 mockup screens.

## Index

- `styles.css` — global entry (import manifest only)
- `tokens/` — colors, typography, spacing, elevation, fonts
- `components/` — primitives above (+ per-directory demo cards)
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand)
- `ui_kits/app/` — interactive recreation of core app screens
- `SKILL.md` — Agent-Skills entry point
- `MyReciBook Mockups.dc.html` — the full mockup canvas (turns 1–6) this
  system was extracted from; `design_handoff_myrecibook/` — the dev handoff.

## Caveats

- Fonts and icons are Google-hosted (matching the app's google_fonts usage);
  offline consumers need a network hit or self-hosted copies.
- Recipe imagery is always the user's own screenshots; the stripe placeholder
  is the only sanctioned stand-in.
- The mockup canvas keeps DittoDatto's `_ds/` folder for its own rendering —
  ignore it when consuming this system; `styles.css` at the root is the entry.
