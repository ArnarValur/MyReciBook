# MyReciBook app — UI kit

Interactive recreation of the core app shell, composed entirely from the
design-system primitives. Source of truth: `MyReciBook Mockups.dc.html`
(screens 3d, 3e, 6a, 6b).

- **Cookbook home** — wordmark header + Synced badge, pill search, filter
  chips (working), 2-up recipe grid → tap opens detail.
- **Recipe detail** — screenshot cover with glass buttons, serving stepper
  (working), checkable ingredients, steps, Start cooking / Grocery CTAs.
- **Import sheet** — FAB opens the bottom sheet: screenshot grid, mode
  toggle, link row, camera + manual-entry doors.
- **Settings** — theme segmented control (actually re-themes the frame),
  storage row (opens the disconnect confirm as a demo), about block.
- Grocery / Plan tabs show their empty states.

`index.html` runs standalone; `screens.jsx` holds the screen components
(`window.MRBApp`).
