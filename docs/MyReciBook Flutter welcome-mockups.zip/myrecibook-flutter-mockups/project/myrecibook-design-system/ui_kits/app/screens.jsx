/* MyReciBook UI kit — core app screens, composed from the design-system
   primitives. Recreated 1:1 from the mockup canvas (turns 1–6). */
const NS = Object.values(window).find(v => v && typeof v === 'object' && v.Icon && v.Button && v.RowCard) || {};
const { Icon, Button, Chip, SearchBar, SegmentedControl, Badge, RecipeCard, RowCard, Meter, SectionLabel, Note, EmptyState, Dialog, NavBar } = NS;

const RECIPES = [
  { title: 'Creamy garlic pasta', meta: '25 min · 4 servings', tag: 'your screenshot', chips: ['All', 'Quick'] },
  { title: "Grandma's kleinur", meta: '1 h · makes 30', tag: 'handwritten card', chips: ['All', 'Sweet'] },
  { title: 'Miso butter salmon', meta: '18 min · 2 servings', tag: 'your screenshot', chips: ['All', 'Quick', 'Favorites'] },
  { title: 'Flatbaka dough', meta: '90 min · 2 pizzas', tag: 'your screenshot', chips: ['All'] },
];

function Header() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <Icon name="menu_book" fill size={26} color="var(--primary)" />
      <span className="mrb-wordmark" style={{ flex: 1, fontSize: 23 }}>MyReciBook</span>
      <Badge tone="success" icon="cloud_done">Synced</Badge>
    </div>
  );
}

function CookbookHome({ onOpenRecipe }) {
  const [chip, setChip] = React.useState('All');
  const shown = RECIPES.filter(r => r.chips.includes(chip));
  return (
    <div style={{ padding: '8px 20px 90px', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <Header />
      <SearchBar placeholder="Search your cookbook…" />
      <div style={{ display: 'flex', gap: 8, overflow: 'hidden', marginRight: -20 }}>
        {['All', 'Favorites', 'Quick', 'Sweet'].map(c => (
          <Chip key={c} selected={chip === c} icon={c === 'Favorites' ? 'favorite' : c === 'Quick' ? 'bolt' : c === 'Sweet' ? 'cake' : undefined} onClick={() => setChip(c)}>{c}</Chip>
        ))}
      </div>
      {shown.length === 0 ? (
        <EmptyState icon="menu_book" title="Nothing here yet" message="Rescue a recipe and tag it — it'll show up under this filter." />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {shown.map(r => <RecipeCard key={r.title} title={r.title} meta={r.meta} coverTag={r.tag} onClick={() => onOpenRecipe(r)} />)}
        </div>
      )}
    </div>
  );
}

function RecipeDetail({ recipe, onBack }) {
  const [servings, setServings] = React.useState(4);
  const [checked, setChecked] = React.useState([1]);
  const toggle = (i) => setChecked(c => c.includes(i) ? c.filter(x => x !== i) : [...c, i]);
  const ingredients = [['400 g', 'spaghetti'], ['3 cloves', 'garlic'], ['250 ml', 'cream']];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100%' }}>
      <div style={{ height: 190, flex: 'none', position: 'relative', background: 'var(--placeholder-stripes)' }}>
        <span className="mrb-mono" style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', fontSize: 10, color: 'var(--on-surface-variant)', background: 'color-mix(in srgb, var(--surface) 75%, transparent)', padding: '3px 8px', borderRadius: 4 }}>your screenshot · auto-cropped</span>
        <button onClick={onBack} style={{ position: 'absolute', top: 14, left: 14, width: 40, height: 40, borderRadius: '50%', background: 'var(--glass-fill)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', border: '1px solid var(--glass-border)', display: 'grid', placeItems: 'center', cursor: 'pointer', color: 'var(--on-surface)' }}><Icon name="arrow_back" size={20} /></button>
        <span style={{ position: 'absolute', top: 14, right: 14, width: 40, height: 40, borderRadius: '50%', background: 'var(--glass-fill)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', border: '1px solid var(--glass-border)', display: 'grid', placeItems: 'center' }}><Icon name="favorite" fill size={20} color="var(--tertiary-container)" /></span>
      </div>
      <div style={{ padding: '16px 20px 20px', display: 'flex', flexDirection: 'column', gap: 12, flex: 1 }}>
        <div className="mrb-headline-lg">{recipe.title}</div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '8px 13px', borderRadius: 'var(--radius-full)', background: 'var(--surface-container-high)', fontSize: 12.5, fontWeight: 500 }}><Icon name="schedule" size={16} color="var(--primary)" />25 min</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2, padding: 2, borderRadius: 'var(--radius-full)', border: '1px solid var(--hairline)', fontSize: 12.5 }}>
            <button onClick={() => setServings(s => Math.max(1, s - 1))} style={{ width: 34, height: 34, borderRadius: '50%', border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--primary)', display: 'grid', placeItems: 'center' }}><Icon name="remove" size={17} /></button>
            <span style={{ fontWeight: 600 }}>{servings} servings</span>
            <button onClick={() => setServings(s => s + 1)} style={{ width: 34, height: 34, borderRadius: '50%', border: 'none', background: 'var(--surface-container-high)', cursor: 'pointer', color: 'var(--primary)', display: 'grid', placeItems: 'center' }}><Icon name="add" size={17} /></button>
          </span>
        </div>
        <SectionLabel>Ingredients</SectionLabel>
        <div style={{ background: 'var(--surface-container-lowest)', border: '1px solid var(--hairline)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--elev-1)', padding: '2px 14px', fontSize: 13.5 }}>
          {ingredients.map(([amt, name], i) => (
            <div key={i} onClick={() => toggle(i)} style={{ padding: '9px 0', borderBottom: i < ingredients.length - 1 ? '1px solid var(--hairline-soft)' : 'none', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
              {checked.includes(i)
                ? <span style={{ width: 18, height: 18, borderRadius: 6, background: 'var(--primary)', display: 'grid', placeItems: 'center' }}><Icon name="check" size={13} color="var(--on-primary)" /></span>
                : <span style={{ width: 18, height: 18, borderRadius: 6, border: '2px solid var(--outline)', boxSizing: 'border-box' }}></span>}
              <span style={{ textDecoration: checked.includes(i) ? 'line-through' : 'none', color: checked.includes(i) ? 'var(--on-surface-variant)' : 'var(--on-surface)' }}><b>{amt}</b> {name}</span>
            </div>
          ))}
        </div>
        <SectionLabel>Steps</SectionLabel>
        <div style={{ background: 'var(--surface-container-lowest)', border: '1px solid var(--hairline)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--elev-1)', padding: '12px 14px', fontSize: 13.5, lineHeight: 1.55 }}>
          <div><b style={{ color: 'var(--primary)' }}>1</b>&nbsp; Boil the pasta in generously salted water until al dente…</div>
          <div style={{ marginTop: 8, color: 'var(--on-surface-variant)' }}><b style={{ color: 'var(--primary)' }}>2</b>&nbsp; Melt butter over medium heat, sweat the garlic…</div>
        </div>
        <div style={{ flex: 1 }}></div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Button icon="play_arrow" style={{ flex: 1.5 }}>Start cooking</Button>
          <Button variant="tonal" icon="playlist_add" style={{ flex: 1 }}>Grocery</Button>
        </div>
      </div>
    </div>
  );
}

function ImportSheet({ onClose }) {
  const [mode, setMode] = React.useState('one');
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 20 }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'color-mix(in srgb, #0b0d16 45%, transparent)' }}></div>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, background: 'var(--surface-container-lowest)', borderRadius: 'var(--radius-xl) var(--radius-xl) 0 0', padding: '10px 20px 22px', display: 'flex', flexDirection: 'column', gap: 11, boxShadow: 'var(--elev-3)' }}>
        <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--outline-variant)', margin: '0 auto' }}></div>
        <div className="mrb-headline-md" style={{ fontSize: 20 }}>Add to your book</div>
        <SectionLabel>From your screenshots</SectionLabel>
        <div className="mrb-caption" style={{ fontSize: 12, marginTop: -6 }}>one recipe or a whole pile — you decide next</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
          {[1, 2].map(n => (
            <div key={n} style={{ height: 80, borderRadius: 'var(--radius-md)', position: 'relative', background: 'var(--placeholder-stripes)', border: '2px solid var(--primary)' }}>
              <span style={{ position: 'absolute', top: 5, right: 5, width: 20, height: 20, borderRadius: '50%', background: 'var(--primary)', color: 'var(--on-primary)', display: 'grid', placeItems: 'center', fontSize: 11.5, fontWeight: 700 }}>{n}</span>
            </div>
          ))}
          <div style={{ height: 80, borderRadius: 'var(--radius-md)', position: 'relative', background: 'var(--placeholder-stripes)' }}>
            <span style={{ position: 'absolute', top: 5, right: 5, width: 20, height: 20, borderRadius: '50%', border: '2px solid color-mix(in srgb, #fff 85%, transparent)', background: 'color-mix(in srgb, #0b0d16 20%, transparent)', boxSizing: 'border-box' }}></span>
          </div>
          <div style={{ height: 80, borderRadius: 'var(--radius-md)', background: 'var(--surface-container-high)', display: 'grid', placeItems: 'center', textAlign: 'center', fontSize: 11, color: 'var(--on-surface-variant)', lineHeight: 1.3 }}>234 more</div>
        </div>
        <SegmentedControl value={mode} onChange={setMode} options={[{ key: 'one', label: 'One recipe · 2 shots', check: false }, { key: 'many', label: '2 separate recipes', check: false }]} />
        <SectionLabel style={{ marginTop: 2 }}>Or fetch from the internet</SectionLabel>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, padding: '11px 16px', border: '1px solid var(--hairline)', borderRadius: 'var(--radius-full)', color: 'var(--on-surface-variant)', fontSize: 13.5 }}><Icon name="link" size={18} />Paste a link — TikTok, IG, blog…</div>
          <span style={{ width: 44, height: 44, flex: 'none', borderRadius: '50%', background: 'var(--secondary-container)', color: 'var(--on-secondary-container)', display: 'grid', placeItems: 'center' }}><Icon name="arrow_forward" size={20} /></span>
        </div>
        {[{ icon: 'photo_camera', t: 'Snap a page', s: "cookbook or grandma's card — handwriting welcome" }, { icon: 'edit', t: 'Type it in yourself', s: 'no AI, no cap — always unlimited' }].map(row => (
          <div key={row.t} style={{ display: 'flex', alignItems: 'center', gap: 12, paddingTop: 10, borderTop: '1px solid var(--hairline)' }}>
            <div style={{ width: 40, height: 40, borderRadius: 'var(--radius-md)', background: 'var(--surface-container-high)', display: 'grid', placeItems: 'center' }}><Icon name={row.icon} size={20} color="var(--on-surface-variant)" /></div>
            <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: 14 }}>{row.t}</div><div className="mrb-caption" style={{ fontSize: 12 }}>{row.s}</div></div>
            <Icon name="chevron_right" color="var(--on-surface-variant)" />
          </div>
        ))}
        <Button fullWidth trailingIcon="arrow_forward" onClick={onClose}>Rescue as one recipe</Button>
      </div>
    </div>
  );
}

function SettingsScreen({ theme, onTheme }) {
  const [confirm, setConfirm] = React.useState(false);
  return (
    <div style={{ padding: '8px 20px 90px', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span className="mrb-headline-md">Settings</span>
      </div>
      <SectionLabel style={{ marginTop: 8 }}>Theme</SectionLabel>
      <SegmentedControl value={theme} onChange={onTheme} options={[{ key: 'system', label: 'System' }, { key: 'light', label: 'Light' }, { key: 'dark', label: 'Dark' }]} />
      <SectionLabel style={{ marginTop: 8 }}>Storage</SectionLabel>
      <RowCard icon="cloud_done" iconTint="primary" title="Where your recipes live" subtitle="This phone + Google Drive · synced 2 min ago" trailing={<Icon name="chevron_right" color="var(--on-surface-variant)" />} onClick={() => setConfirm(true)} />
      <SectionLabel style={{ marginTop: 8 }}>About</SectionLabel>
      <div style={{ background: 'var(--surface-container-lowest)', border: '1px solid var(--hairline)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--elev-1)', padding: '2px 14px', fontSize: 14 }}>
        <div style={{ padding: '13px 0', display: 'flex', alignItems: 'center', gap: 12 }}><Icon name="description" size={20} color="var(--on-surface-variant)" /><span style={{ flex: 1 }}>Open-source licenses</span><Icon name="chevron_right" size={20} color="var(--on-surface-variant)" /></div>
      </div>
      <div style={{ textAlign: 'center', fontSize: 11.5, color: 'var(--on-surface-variant)', marginTop: 16 }}>MyReciBook 1.2 · you own this copy</div>
      {confirm && (
        <Dialog
          contained
          title="Disconnect Google Drive?"
          message="Nothing is deleted. Your recipes stay in your Drive folder and in the copy on this phone — they just stop syncing."
          confirmLabel="Disconnect"
          destructive
          onConfirm={() => setConfirm(false)}
          onCancel={() => setConfirm(false)}
        />
      )}
    </div>
  );
}

window.MRBApp = { CookbookHome, RecipeDetail, ImportSheet, SettingsScreen, Header };
