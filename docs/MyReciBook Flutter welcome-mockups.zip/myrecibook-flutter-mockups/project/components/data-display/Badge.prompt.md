Small tonal status pill.

```jsx
<Badge tone="success" icon="cloud_done">Synced</Badge>
<Badge tone="success" icon="verified">Owned</Badge>
<Badge tone="warning" icon="schedule">Waiting</Badge>
```
