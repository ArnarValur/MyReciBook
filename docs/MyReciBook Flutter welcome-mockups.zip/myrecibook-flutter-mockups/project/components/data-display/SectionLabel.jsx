/**
 * SectionLabel — the 11px tracked-out uppercase eyebrow labelling every
 * content group ("INGREDIENTS · 8", "UNDER THE HOOD").
 */
export function SectionLabel({ children, count, trailing, style = {}, ...rest }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        fontFamily: 'var(--font-body)',
        fontWeight: 'var(--weight-semibold)',
        fontSize: 11,
        letterSpacing: '0.9px',
        textTransform: 'uppercase',
        color: 'var(--on-surface-variant)',
        ...style,
      }}
      {...rest}
    >
      <span>{children}{count != null && ` · ${count}`}</span>
      {trailing}
    </div>
  );
}
