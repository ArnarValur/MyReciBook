Fair-use meter with honest mono count. Lives on "Your copy" and the cap-reached sheet.

```jsx
<Meter label="2026 AI rescues" value={245} max={600} footnote="Resets 1 January. Typing recipes in yourself is always unlimited." />
```
