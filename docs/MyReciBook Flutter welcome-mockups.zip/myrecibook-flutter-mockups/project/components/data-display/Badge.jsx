/**
 * Badge — small tonal status pill: "Synced", "Owned". Tones map to the
 * theme-stable status colors.
 */
const TONES = {
  primary: { bg: 'color-mix(in srgb, var(--primary) 15%, transparent)', fg: 'var(--primary)' },
  success: { bg: 'color-mix(in srgb, var(--success) 12%, transparent)', fg: 'var(--success)' },
  warning: { bg: 'color-mix(in srgb, var(--warning) 12%, transparent)', fg: 'var(--warning)' },
  error: { bg: 'color-mix(in srgb, var(--error) 12%, transparent)', fg: 'var(--error)' },
  neutral: { bg: 'color-mix(in srgb, var(--on-surface) 6%, transparent)', fg: 'var(--on-surface-variant)' },
};

export function Badge({ children, tone = 'neutral', icon, style = {}, ...rest }) {
  const t = TONES[tone] || TONES.neutral;
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4,
        padding: '4px 8px',
        borderRadius: 'var(--radius-sm)',
        background: t.bg,
        color: t.fg,
        fontFamily: 'var(--font-body)',
        fontSize: 11,
        fontWeight: 'var(--weight-bold)',
        letterSpacing: '0.3px',
        lineHeight: 1.2,
        whiteSpace: 'nowrap',
        ...style,
      }}
      {...rest}
    >
      {icon && <span className="material-symbols-rounded" style={{ fontSize: 14 }}>{icon}</span>}
      {children}
    </span>
  );
}
