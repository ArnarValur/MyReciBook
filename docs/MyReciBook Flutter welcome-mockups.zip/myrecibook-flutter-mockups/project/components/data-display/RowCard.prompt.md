The workhorse row card: leading icon square or screenshot thumb, title + subtitle, trailing slot, optional action row. Storage cards, import doors, restore steps, queue items.

```jsx
<RowCard icon="phone_android" iconTint="secondary" title="This phone" subtitle="zero setup · works offline" trailing={<Icon name="check_circle" fill color="var(--primary)" size={22} />} selected />
<RowCard thumb title="Couldn't read this one" subtitle="nothing spent — the shot stays in your gallery" tone="error" trailing={<Button variant="tonal" size="sm">Retry</Button>} />
<RowCard icon="cloud" title="Dropbox" subtitle="awaiting keys in this build" dimmed />
```

`children` renders an action row under the content (`<Button size="sm">` pairs).
