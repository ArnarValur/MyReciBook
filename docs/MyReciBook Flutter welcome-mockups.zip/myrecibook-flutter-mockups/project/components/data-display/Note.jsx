/**
 * Note — dashed reassurance box; the app's quiet honest asides
 * ("Move, export or leave anytime…").
 */
export function Note({ children, style = {}, ...rest }) {
  return (
    <div
      style={{
        border: '1px dashed color-mix(in srgb, var(--outline) 60%, transparent)',
        borderRadius: 'var(--radius-md)',
        padding: '11px 13px',
        fontFamily: 'var(--font-body)',
        fontSize: 12.5,
        lineHeight: 1.5,
        color: 'var(--on-surface-variant)',
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
