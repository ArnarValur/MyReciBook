/**
 * RowCard — the app's workhorse list card: leading icon-in-rounded-square or
 * portrait thumb, title + subtitle, trailing slot. Covers storage cards,
 * import doors, restore steps and batch-queue items.
 * Accents: selected (primary border + glow), tone warning/error (flagged
 * cards), dimmed (skipped / awaiting keys).
 */
export function RowCard({ icon, iconTint = 'muted', thumb = false, thumbSrc, title, subtitle, subtitleColor, trailing, selected = false, tone, dimmed = false, onClick, children, style = {}, ...rest }) {
  const tints = {
    muted: { bg: 'var(--surface-container-high)', fg: 'var(--on-surface-variant)' },
    primary: { bg: 'var(--surface-container-high)', fg: 'var(--primary)' },
    secondary: { bg: 'var(--secondary-container)', fg: 'var(--on-secondary-container)' },
  };
  const t = tints[iconTint] || tints.muted;
  const border = selected
    ? '1.5px solid var(--primary)'
    : tone === 'warning'
      ? '1.5px solid color-mix(in srgb, var(--warning) 55%, transparent)'
      : tone === 'error'
        ? '1.5px solid color-mix(in srgb, var(--error) 55%, transparent)'
        : '1px solid var(--hairline)';
  const subColor = subtitleColor
    || (tone === 'warning' ? 'color-mix(in srgb, var(--warning) 55%, var(--on-surface))'
      : tone === 'error' ? 'color-mix(in srgb, var(--error) 55%, var(--on-surface))'
        : 'var(--on-surface-variant)');
  return (
    <div
      onClick={onClick}
      style={{
        background: 'var(--surface-container-lowest)',
        border,
        borderRadius: 'var(--radius-md)',
        boxShadow: selected ? 'var(--glow-primary)' : dimmed ? 'none' : 'var(--elev-1)',
        padding: 13,
        opacity: dimmed ? 0.6 : 1,
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
      {...rest}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {thumb && (
          <div style={{ width: 44, height: 60, flex: 'none', borderRadius: 'var(--radius-sm)', background: thumbSrc ? `url(${thumbSrc}) center/cover` : 'var(--placeholder-stripes)' }}></div>
        )}
        {icon && !thumb && (
          <div style={{ width: 40, height: 40, flex: 'none', borderRadius: 'var(--radius-md)', background: t.bg, display: 'grid', placeItems: 'center' }}>
            <span className="material-symbols-rounded" style={{ fontSize: 21, color: t.fg }}>{icon}</span>
          </div>
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
          {title && <div style={{ fontFamily: 'var(--font-body)', fontWeight: 'var(--weight-semibold)', fontSize: 14.5, color: 'var(--on-surface)' }}>{title}</div>}
          {subtitle && <div style={{ fontFamily: 'var(--font-body)', fontSize: 12, marginTop: 2, color: subColor, fontWeight: tone ? 'var(--weight-medium)' : 'var(--weight-regular)' }}>{subtitle}</div>}
        </div>
        {trailing}
      </div>
      {children && <div style={{ display: 'flex', gap: 8, marginTop: 11 }}>{children}</div>}
    </div>
  );
}
