import * as React from 'react';

export interface RowCardProps {
  /** Leading Material Symbols glyph in a 40×40 rounded square */
  icon?: string;
  /** Leading icon tint @default 'muted' */
  iconTint?: 'muted' | 'primary' | 'secondary';
  /** 44×60 portrait screenshot thumb instead of an icon @default false */
  thumb?: boolean;
  /** Image URL for the thumb; striped placeholder when omitted */
  thumbSrc?: string;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  /** Override the subtitle color */
  subtitleColor?: string;
  /** Trailing slot: Button, Badge, Icon, chevron… */
  trailing?: React.ReactNode;
  /** Primary border + glow (chosen/active card) @default false */
  selected?: boolean;
  /** Flagged-card accent (border + subtitle color) */
  tone?: 'warning' | 'error';
  /** 60% opacity — skipped items, unavailable options @default false */
  dimmed?: boolean;
  onClick?: () => void;
  /** Action row rendered under the content (e.g. sm buttons) */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export declare function RowCard(props: RowCardProps): JSX.Element;
