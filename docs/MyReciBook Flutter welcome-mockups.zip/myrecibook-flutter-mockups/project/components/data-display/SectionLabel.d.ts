import * as React from 'react';

export interface SectionLabelProps {
  children?: React.ReactNode;
  /** Appends " · N" */
  count?: number;
  /** Trailing slot (e.g. a tiny pill tag) */
  trailing?: React.ReactNode;
  style?: React.CSSProperties;
}

export declare function SectionLabel(props: SectionLabelProps): JSX.Element;
