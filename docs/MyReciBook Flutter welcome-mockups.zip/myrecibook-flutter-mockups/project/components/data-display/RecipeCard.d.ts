import * as React from 'react';

export interface RecipeCardProps {
  title: React.ReactNode;
  /** Meta line, e.g. "25 min · 4 servings" */
  meta?: React.ReactNode;
  /** Cover image URL; striped placeholder when omitted */
  cover?: string;
  /** Mono tag shown on the placeholder @default 'your screenshot' */
  coverTag?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export declare function RecipeCard(props: RecipeCardProps): JSX.Element;
