import * as React from 'react';

export interface NoteProps {
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export declare function Note(props: NoteProps): JSX.Element;
