Tracked uppercase eyebrow above every content group.

```jsx
<SectionLabel count={8}>Ingredients</SectionLabel>
<SectionLabel>From your screenshots</SectionLabel>
```
