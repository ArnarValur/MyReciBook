/**
 * Meter — the fair-use rescue meter: label + mono count, track, footnote.
 * Counts are honest; the footnote restates the unlimited-typing promise.
 */
export function Meter({ label, value = 0, max = 100, count, footnote, style = {}, ...rest }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ fontFamily: 'var(--font-body)', ...style }} {...rest}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, fontWeight: 'var(--weight-semibold)', color: 'var(--on-surface)' }}>
        <span>{label}</span>
        <span style={{ fontFamily: 'var(--font-mono)' }}>{count != null ? count : `${value} / ${max}`}</span>
      </div>
      <div style={{ height: 8, borderRadius: 4, background: 'var(--surface-container-high)', marginTop: 8, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${pct}%`, background: 'var(--primary)', borderRadius: 4 }}></div>
      </div>
      {footnote && <div style={{ fontSize: 11.5, color: 'var(--on-surface-variant)', marginTop: 8, lineHeight: 1.5 }}>{footnote}</div>}
    </div>
  );
}
