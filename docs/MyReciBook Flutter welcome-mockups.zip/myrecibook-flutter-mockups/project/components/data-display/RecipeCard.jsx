/**
 * RecipeCard — cookbook grid tile: screenshot cover (striped placeholder with
 * a mono tag when no image), title, meta line.
 */
export function RecipeCard({ title, meta, cover, coverTag = 'your screenshot', onClick, style = {}, ...rest }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: 'var(--surface-container-lowest)',
        border: '1px solid var(--hairline)',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        boxShadow: 'var(--elev-1)',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
      {...rest}
    >
      <div style={{ height: 108, background: cover ? `url(${cover}) center/cover` : 'var(--placeholder-stripes)', display: 'grid', placeItems: 'center' }}>
        {!cover && coverTag && (
          <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500, fontSize: 9.5, color: 'var(--on-surface-variant)', background: 'color-mix(in srgb, var(--surface) 75%, transparent)', padding: '2px 6px', borderRadius: 4 }}>{coverTag}</span>
        )}
      </div>
      <div style={{ padding: '9px 11px 11px' }}>
        <div style={{ fontFamily: 'var(--font-body)', fontWeight: 'var(--weight-semibold)', fontSize: 13.5, lineHeight: 1.3, color: 'var(--on-surface)' }}>{title}</div>
        {meta && <div style={{ fontFamily: 'var(--font-body)', fontSize: 11.5, color: 'var(--on-surface-variant)', marginTop: 3 }}>{meta}</div>}
      </div>
    </div>
  );
}
