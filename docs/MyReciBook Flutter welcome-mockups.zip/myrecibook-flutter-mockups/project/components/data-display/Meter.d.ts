import * as React from 'react';

export interface MeterProps {
  /** e.g. "2026 AI rescues" */
  label: React.ReactNode;
  /** Current value @default 0 */
  value?: number;
  /** @default 100 */
  max?: number;
  /** Override the mono count text (defaults to "value / max") */
  count?: React.ReactNode;
  /** Small print under the bar */
  footnote?: React.ReactNode;
  style?: React.CSSProperties;
}

export declare function Meter(props: MeterProps): JSX.Element;
