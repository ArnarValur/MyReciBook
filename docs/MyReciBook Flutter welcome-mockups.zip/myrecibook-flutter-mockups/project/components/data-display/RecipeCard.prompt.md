Cookbook grid tile (2-up grid, 12px gutters). Covers are the user's screenshots — placeholder stripes otherwise.

```jsx
<RecipeCard title="Creamy garlic pasta" meta="25 min · 4 servings" />
<RecipeCard title="Grandma's kleinur" meta="1 h · makes 30" coverTag="handwritten card" />
```
