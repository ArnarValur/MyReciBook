Dashed reassurance note — one quiet honest aside per screen, max.

```jsx
<Note>Move, export or leave anytime. If MyReciBook vanished tomorrow, your recipes wouldn't.</Note>
```
