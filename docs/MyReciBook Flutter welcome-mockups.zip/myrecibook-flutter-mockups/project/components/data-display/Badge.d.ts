import * as React from 'react';

export interface BadgeProps {
  children?: React.ReactNode;
  /** @default 'neutral' */
  tone?: 'primary' | 'success' | 'warning' | 'error' | 'neutral';
  /** Leading Material Symbols glyph, e.g. "cloud_done" */
  icon?: string;
  style?: React.CSSProperties;
}

export declare function Badge(props: BadgeProps): JSX.Element;
