import * as React from 'react';

export interface IconProps {
  /** Material Symbols Rounded glyph name, e.g. "menu_book" */
  name: string;
  /** Font size in px @default 24 */
  size?: number;
  /** Variable-font weight 100–700 @default 400 */
  weight?: number;
  /** Filled axis — use for active/selected/success @default false */
  fill?: boolean;
  /** CSS color @default 'currentColor' */
  color?: string;
  style?: React.CSSProperties;
}

export declare function Icon(props: IconProps): JSX.Element;
