/**
 * Icon — Material Symbols Rounded glyph, MyReciBook's single icon system.
 * Use fill for active/selected/success states.
 */
export function Icon({ name, size = 24, weight = 400, fill = false, color = 'currentColor', style = {}, ...rest }) {
  return (
    <span
      className="material-symbols-rounded"
      style={{
        fontSize: size,
        lineHeight: 1,
        color,
        fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' ${weight}, 'GRAD' 0, 'opsz' ${Math.min(Math.max(size, 20), 48)}`,
        userSelect: 'none',
        ...style,
      }}
      {...rest}
    >
      {name}
    </span>
  );
}
