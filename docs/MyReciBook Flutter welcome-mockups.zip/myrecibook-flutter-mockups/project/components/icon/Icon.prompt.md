Material Symbols Rounded glyph wrapper — the only sanctioned icon system; never hand-roll SVGs or use emoji.

```jsx
<Icon name="menu_book" fill color="var(--primary)" />
<Icon name="chevron_right" size={20} color="var(--on-surface-variant)" />
```

`fill` marks active/selected/success (active nav item, favorite heart, check_circle).
