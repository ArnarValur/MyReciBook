import * as React from 'react';

/**
 * @startingPoint section="Components" subtitle="Filled, tonal, outlined, text and danger buttons" viewport="700x220"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** @default 'filled' */
  variant?: 'filled' | 'tonal' | 'outlined' | 'text' | 'danger';
  /** @default 'md' */
  size?: 'sm' | 'md';
  /** Leading Material Symbols glyph name */
  icon?: string;
  /** Trailing glyph, e.g. "arrow_forward" on forward CTAs */
  trailingIcon?: string;
  /** Full-width stadium CTA at the screen bottom @default false */
  fullWidth?: boolean;
  /** @default false */
  disabled?: boolean;
  style?: React.CSSProperties;
}

export declare function Button(props: ButtonProps): JSX.Element;
