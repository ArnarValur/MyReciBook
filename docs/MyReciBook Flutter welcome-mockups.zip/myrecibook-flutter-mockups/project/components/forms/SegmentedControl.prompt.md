Pill segmented toggle for 2–3 mutually exclusive choices (import mode, theme).

```jsx
<SegmentedControl options={['System', 'Light', 'Dark']} value="System" onChange={setTheme} />
<SegmentedControl options={[{key:'one', label:'One recipe · 2 shots', check:false}, {key:'many', label:'2 separate recipes', check:false}]} value="one" />
```
