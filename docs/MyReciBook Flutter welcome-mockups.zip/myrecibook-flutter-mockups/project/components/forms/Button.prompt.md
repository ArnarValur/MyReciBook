Primary action button; the app's screen-bottom CTAs are `fullWidth` filled buttons ("Save to cookbook", "Restore purchase").

```jsx
<Button fullWidth trailingIcon="arrow_forward">Rescue as one recipe</Button>
<Button variant="tonal" size="sm">Retry</Button>
<Button variant="danger">Disconnect</Button>
```

Variants: filled · tonal · outlined · text · danger. Sizes sm (36px, card actions) / md (48px). `icon`/`trailingIcon` take Material Symbols names.
