import * as React from 'react';

export interface SegmentedOption {
  key: string;
  label: string;
  /** Hide the leading check on the active segment @default true */
  check?: boolean;
}

export interface SegmentedControlProps {
  /** Strings or {key, label} objects */
  options: Array<string | SegmentedOption>;
  /** Active option key */
  value?: string;
  onChange?: (key: string) => void;
  style?: React.CSSProperties;
}

export declare function SegmentedControl(props: SegmentedControlProps): JSX.Element;
