Filter chip pill for the cookbook filter row.

```jsx
<Chip selected>All</Chip>
<Chip icon="favorite">Favorites</Chip>
<Chip icon="bolt">Quick</Chip>
```
