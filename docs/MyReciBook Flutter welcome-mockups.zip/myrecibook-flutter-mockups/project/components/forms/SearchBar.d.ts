import * as React from 'react';

export interface SearchBarProps {
  /** @default 'Search your cookbook…' */
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Frosted-glass treatment for floating over imagery @default false */
  glass?: boolean;
  style?: React.CSSProperties;
}

export declare function SearchBar(props: SearchBarProps): JSX.Element;
