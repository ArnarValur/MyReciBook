/**
 * MyReciBook Button. Variants: filled (primary), tonal (secondary-container),
 * outlined (1.5px secondary), text, danger (solid error). Stadium CTAs are
 * `fullWidth` filled buttons.
 */
export function Button({ children, variant = 'filled', size = 'md', icon, trailingIcon, fullWidth = false, disabled = false, style = {}, ...rest }) {
  const sizes = {
    sm: { padding: '8px 16px', fontSize: 13, minHeight: 36 },
    md: { padding: '14px 24px', fontSize: 14, minHeight: 48 },
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    filled: { background: 'var(--primary)', color: 'var(--on-primary)', boxShadow: 'var(--elev-1)' },
    tonal: { background: 'var(--secondary-container)', color: 'var(--on-secondary-container)' },
    outlined: { background: 'transparent', color: 'var(--primary)', border: '1.5px solid var(--secondary)' },
    text: { background: 'transparent', color: 'var(--primary)', padding: size === 'sm' ? '8px 12px' : '12px 16px' },
    danger: { background: 'var(--error)', color: 'var(--on-error)', boxShadow: 'var(--elev-1)' },
  };
  const iconSize = size === 'sm' ? 18 : 20;
  const glyph = (name) => (
    <span className="material-symbols-rounded" style={{ fontSize: iconSize, lineHeight: 1 }}>{name}</span>
  );
  return (
    <button
      type="button"
      disabled={disabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        fontFamily: 'var(--font-body)',
        fontWeight: 'var(--weight-semibold)',
        fontSize: s.fontSize,
        lineHeight: 1,
        padding: s.padding,
        minHeight: s.minHeight,
        width: fullWidth ? '100%' : 'auto',
        borderRadius: 'var(--radius-sm)',
        border: 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'background var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
        whiteSpace: 'nowrap',
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {icon && glyph(icon)}
      {children}
      {trailingIcon && glyph(trailingIcon)}
    </button>
  );
}
