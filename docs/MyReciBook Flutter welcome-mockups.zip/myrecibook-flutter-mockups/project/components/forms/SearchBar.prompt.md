Pill search field for the cookbook header.

```jsx
<SearchBar placeholder="Search your cookbook…" />
```

`glass` gives the frosted treatment when floating over recipe imagery.
