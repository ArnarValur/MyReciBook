import * as React from 'react';

export interface ChipProps {
  children?: React.ReactNode;
  /** Leading Material Symbols glyph, e.g. "favorite" */
  icon?: string;
  /** @default false */
  selected?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export declare function Chip(props: ChipProps): JSX.Element;
