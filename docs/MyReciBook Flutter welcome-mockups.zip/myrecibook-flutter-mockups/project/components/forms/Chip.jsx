/**
 * Chip — filter pill for the cookbook header row (All / Favorites / Quick…).
 * Selected = primary-container fill (leading check when no icon).
 */
export function Chip({ children, icon, selected = false, onClick, style = {}, ...rest }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 36,
        padding: icon ? '0 14px 0 10px' : '0 16px',
        borderRadius: 'var(--radius-full)',
        border: 'none',
        cursor: 'pointer',
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        fontWeight: 'var(--weight-medium)',
        whiteSpace: 'nowrap',
        background: selected ? 'var(--primary-container)' : 'color-mix(in srgb, var(--surface-container-highest) 50%, transparent)',
        color: selected ? 'var(--on-primary-container)' : 'var(--on-surface-variant)',
        transition: 'background var(--dur-fast) var(--ease-standard)',
        ...style,
      }}
      {...rest}
    >
      {selected && !icon && <span className="material-symbols-rounded" style={{ fontSize: 18 }}>check</span>}
      {icon && <span className="material-symbols-rounded" style={{ fontSize: 18 }}>{icon}</span>}
      {children}
    </button>
  );
}
