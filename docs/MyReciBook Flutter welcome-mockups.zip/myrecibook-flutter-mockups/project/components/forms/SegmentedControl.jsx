/**
 * SegmentedControl — pill toggle on a surface-container-high track.
 * Used for the import-mode choice ("One recipe · 2 shots" / "2 separate
 * recipes") and the settings theme row (System / Light / Dark).
 */
export function SegmentedControl({ options = [], value, onChange, style = {}, ...rest }) {
  return (
    <div
      style={{
        display: 'flex',
        background: 'var(--surface-container-high)',
        borderRadius: 'var(--radius-full)',
        padding: 3,
        fontFamily: 'var(--font-body)',
        fontSize: 12.5,
        ...style,
      }}
      {...rest}
    >
      {options.map((opt) => {
        const o = typeof opt === 'string' ? { key: opt, label: opt } : opt;
        const active = o.key === value;
        return (
          <button
            key={o.key}
            type="button"
            onClick={() => onChange && onChange(o.key)}
            style={{
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 5,
              padding: '9px 4px',
              border: 'none',
              cursor: 'pointer',
              borderRadius: 'var(--radius-full)',
              background: active ? 'var(--surface-container-lowest)' : 'transparent',
              color: active ? 'var(--primary)' : 'var(--on-surface-variant)',
              fontFamily: 'inherit',
              fontSize: 'inherit',
              fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)',
              boxShadow: active ? 'var(--elev-1)' : 'none',
              transition: 'background var(--dur-fast) var(--ease-standard)',
              whiteSpace: 'nowrap',
            }}
          >
            {active && o.check !== false && <span className="material-symbols-rounded" style={{ fontSize: 16 }}>check</span>}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
