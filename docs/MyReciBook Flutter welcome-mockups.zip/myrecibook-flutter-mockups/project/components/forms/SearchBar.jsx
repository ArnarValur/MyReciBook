/**
 * SearchBar — pill search field ("Search your cookbook…"). 48px, translucent
 * surface fill; `glass` for floating over imagery.
 */
export function SearchBar({ placeholder = 'Search your cookbook…', value, onChange, glass = false, style = {}, ...rest }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        height: 48,
        padding: '0 16px',
        borderRadius: 'var(--radius-full)',
        background: glass ? 'var(--glass-fill)' : 'color-mix(in srgb, var(--surface-container-highest) 50%, transparent)',
        border: glass ? '1px solid var(--glass-border)' : 'none',
        backdropFilter: glass ? 'blur(var(--blur-glass-strong))' : 'none',
        WebkitBackdropFilter: glass ? 'blur(var(--blur-glass-strong))' : 'none',
        ...style,
      }}
    >
      <span className="material-symbols-rounded" style={{ fontSize: 22, color: 'var(--primary)' }}>search</span>
      <input
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        style={{
          flex: 1,
          border: 'none',
          outline: 'none',
          background: 'transparent',
          fontFamily: 'var(--font-body)',
          fontSize: 15,
          color: 'var(--on-surface)',
          minWidth: 0,
        }}
        {...rest}
      />
    </div>
  );
}
