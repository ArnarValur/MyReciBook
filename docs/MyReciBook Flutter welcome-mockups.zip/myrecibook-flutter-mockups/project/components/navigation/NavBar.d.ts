import * as React from 'react';

export interface NavItem {
  key: string;
  /** Material Symbols glyph */
  icon: string;
  label: string;
}

export interface NavBarProps {
  /** @default Cookbook/Grocery/Plan/Settings */
  items?: NavItem[];
  /** Active item key */
  active?: string;
  onSelect?: (key: string) => void;
  /** Center FAB glyph — the import door @default 'add' */
  fabIcon?: string;
  onFab?: () => void;
  style?: React.CSSProperties;
}

export declare function NavBar(props: NavBarProps): JSX.Element;
