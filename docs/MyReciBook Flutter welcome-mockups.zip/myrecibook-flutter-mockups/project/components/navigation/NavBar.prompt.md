Glass bottom nav with center FAB (the import door). Pin ~16px above the screen bottom; content scrolls beneath.

```jsx
<NavBar active="cookbook" fabIcon="add" onFab={openImportSheet} onSelect={setTab} />
```

Default items: Cookbook · Grocery · Plan · Settings. Active item fills its glyph.
