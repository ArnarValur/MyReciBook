const DEFAULT_ITEMS = [
  { key: 'cookbook', icon: 'menu_book', label: 'Cookbook' },
  { key: 'grocery', icon: 'checklist', label: 'Grocery' },
  { key: 'plan', icon: 'calendar_month', label: 'Plan' },
  { key: 'settings', icon: 'settings', label: 'Settings' },
];

/**
 * NavBar — glass bottom navigation: four icon items split around a
 * protruding gradient FAB (the import door). Floats over content.
 */
export function NavBar({ items = DEFAULT_ITEMS, active, onSelect, fabIcon = 'add', onFab, style = {} }) {
  const left = items.slice(0, 2);
  const right = items.slice(2);
  const renderItem = (it) => {
    const isActive = it.key === active;
    return (
      <button
        key={it.key}
        type="button"
        onClick={() => onSelect && onSelect(it.key)}
        style={{
          flex: 1,
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 3,
          padding: 0,
          color: isActive ? 'var(--primary)' : 'var(--on-surface-variant)',
        }}
      >
        <span className="material-symbols-rounded" style={{ fontSize: 22, fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}>{it.icon}</span>
        <span style={{ fontSize: 9, fontWeight: isActive ? 700 : 500, letterSpacing: '0.3px', fontFamily: 'var(--font-body)' }}>{it.label}</span>
      </button>
    );
  };
  return (
    <div style={{ position: 'relative', padding: '0 16px', ...style }}>
      <div
        style={{
          position: 'relative',
          height: 56,
          borderRadius: 'var(--radius-full)',
          background: 'var(--glass-fill)',
          border: '1px solid var(--glass-border)',
          backdropFilter: 'blur(var(--blur-glass-strong))',
          WebkitBackdropFilter: 'blur(var(--blur-glass-strong))',
          display: 'flex',
          alignItems: 'center',
          padding: '0 8px',
        }}
      >
        {left.map(renderItem)}
        <div style={{ width: 60, flexShrink: 0 }}></div>
        {right.map(renderItem)}
      </div>
      <button
        type="button"
        onClick={onFab}
        style={{
          position: 'absolute',
          top: -8,
          left: '50%',
          transform: 'translateX(-50%)',
          width: 52,
          height: 52,
          borderRadius: 'var(--radius-full)',
          border: 'none',
          cursor: 'pointer',
          background: 'linear-gradient(135deg, var(--primary-container), var(--primary))',
          color: 'var(--on-primary)',
          display: 'grid',
          placeItems: 'center',
          boxShadow: 'var(--glow-fab)',
        }}
      >
        <span className="material-symbols-rounded" style={{ fontSize: 26 }}>{fabIcon}</span>
      </button>
    </div>
  );
}
