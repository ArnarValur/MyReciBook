Centered empty/error state. Copy sells the next action, never a sad dead end.

```jsx
<EmptyState icon="menu_book" title="Your book is empty (for now)" message="Somewhere in your camera roll, a pile of recipes is waiting to be rescued." action={<Button icon="add">Rescue your first recipe</Button>} />
```
