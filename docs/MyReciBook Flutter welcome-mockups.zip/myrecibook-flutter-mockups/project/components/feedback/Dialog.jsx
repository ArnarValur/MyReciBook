import { Button } from '../forms/Button.jsx';

/**
 * Dialog — modal confirm: scrim + 24px-radius card, title, message,
 * Cancel/Confirm. Destructive confirms follow the house rule: the message
 * says what survives before what stops; the confirm repeats the verb.
 * `contained` positions absolutely (for phone frames) instead of fixed.
 */
export function Dialog({ open = true, title, message, confirmLabel = 'Confirm', cancelLabel = 'Cancel', destructive = false, contained = false, onConfirm, onCancel }) {
  if (!open) return null;
  return (
    <div
      onClick={onCancel}
      style={{
        position: contained ? 'absolute' : 'fixed',
        inset: 0,
        background: 'color-mix(in srgb, #0b0d16 45%, transparent)',
        display: 'grid',
        placeItems: 'center',
        padding: 20,
        zIndex: 1000,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: 360,
          background: 'var(--surface-container-lowest)',
          borderRadius: 'var(--radius-xl)',
          boxShadow: 'var(--elev-3)',
          padding: 24,
        }}
      >
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-semibold)', fontSize: 20, lineHeight: 1.3, color: 'var(--on-surface)' }}>{title}</div>
        {message && <p style={{ margin: '12px 0 0', fontFamily: 'var(--font-body)', fontSize: 14, lineHeight: 1.55, color: 'var(--on-surface-variant)' }}>{message}</p>}
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 24 }}>
          <Button variant="text" onClick={onCancel}>{cancelLabel}</Button>
          <Button variant={destructive ? 'danger' : 'filled'} onClick={onConfirm}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  );
}
