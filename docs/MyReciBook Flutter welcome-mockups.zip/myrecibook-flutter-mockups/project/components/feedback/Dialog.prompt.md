Modal confirm dialog. Destructive rule: message states what survives before what stops; confirm repeats the verb; Cancel is the safe default.

```jsx
<Dialog
  title="Disconnect Google Drive?"
  message="Nothing is deleted. Your recipes stay in your Drive folder and in the copy on this phone — they just stop syncing."
  confirmLabel="Disconnect" destructive
  onConfirm={...} onCancel={...}
/>
```

`contained` keeps the scrim inside a `position:relative` phone frame.
