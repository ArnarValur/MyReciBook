/**
 * EmptyState — centered icon + title + message + optional action.
 * tone="error" for failure views.
 */
export function EmptyState({ icon, title, message, action, tone = 'neutral', style = {}, ...rest }) {
  const iconColor = tone === 'error' ? 'var(--error)' : 'color-mix(in srgb, var(--primary) 40%, transparent)';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 8, padding: 32, fontFamily: 'var(--font-body)', ...style }} {...rest}>
      <span className="material-symbols-rounded" style={{ fontSize: 56, color: iconColor, marginBottom: 8 }}>{icon || (tone === 'error' ? 'cloud_off' : 'menu_book')}</span>
      {title && <div style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-bold)', fontSize: 18, color: 'var(--on-surface-variant)' }}>{title}</div>}
      {message && <p style={{ margin: 0, maxWidth: 300, color: 'color-mix(in srgb, var(--on-surface-variant) 80%, transparent)', fontSize: 14, lineHeight: 1.5 }}>{message}</p>}
      {action && <div style={{ marginTop: 12 }}>{action}</div>}
    </div>
  );
}
