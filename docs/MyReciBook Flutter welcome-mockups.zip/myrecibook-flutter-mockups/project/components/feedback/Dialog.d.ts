import * as React from 'react';

export interface DialogProps {
  /** @default true */
  open?: boolean;
  title: React.ReactNode;
  message?: React.ReactNode;
  /** @default 'Confirm' */
  confirmLabel?: string;
  /** @default 'Cancel' */
  cancelLabel?: string;
  /** Danger confirm button @default false */
  destructive?: boolean;
  /** position:absolute instead of fixed — for phone-frame mockups @default false */
  contained?: boolean;
  onConfirm?: () => void;
  onCancel?: () => void;
}

export declare function Dialog(props: DialogProps): JSX.Element | null;
