import * as React from 'react';

export interface EmptyStateProps {
  /** Material Symbols glyph @default 'menu_book' ('cloud_off' when tone="error") */
  icon?: string;
  title?: React.ReactNode;
  message?: React.ReactNode;
  /** Action slot, typically a Button */
  action?: React.ReactNode;
  /** @default 'neutral' */
  tone?: 'neutral' | 'error';
  style?: React.CSSProperties;
}

export declare function EmptyState(props: EmptyStateProps): JSX.Element;
