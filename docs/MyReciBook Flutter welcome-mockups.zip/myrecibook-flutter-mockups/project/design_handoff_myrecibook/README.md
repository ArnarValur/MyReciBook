# Handoff: MyReciBook — Android MVP screens

## Overview
MyReciBook is an Android-first (Flutter/Dart) recipe app. Core thesis: **screenshot-first AI import + user-owned recipe files + pay-once pricing**, marketed as "rescue the recipes buried in your camera roll." This package covers the 12 designed screens/states of the MVP: import, extraction review, cookbook, recipe detail, cook mode, grocery list, paywall, storage setup, and edge states.

Product source-of-truth documents (in the parent project, not this bundle): `uploads/context.md` (constraints, gates, build order) and `uploads/recipe-app-feasibility-report.md` (strategy, cited as §…). Where a design decision traces to one, it's noted.

## About the Design Files
`design/MyReciBook Mockups.dc.html` is a **design reference created in HTML** — a prototype showing intended look and behavior, not production code. It renders inside its original design environment; some scaffolding (design-system bundle under `_ds/`, `support.js`) is not included here, so treat it as source to *read*, not to run. The task is to **recreate these designs in Flutter** using Material 3 (`ThemeData` + standard widgets), matching the tokens below. The file contains 4 iteration "turns": **turn 3 (ids 3a–3h) and turn 4 (4a–4d) are the hi-fi spec; turns 1–2 are superseded wireframes** kept for rationale (their orange annotations explain intent).

## Fidelity
**High-fidelity** for turns 3–4: colors, type, spacing, radii, and copy are final intent — recreate faithfully with the Flutter theme below. Striped areas labeled `your screenshot` are image placeholders for user content, never shipped artwork.

## Target & Conventions
- 360dp-wide reference frame (Galaxy S21). All px values below = dp 1:1.
- Material 3, **Material Symbols Rounded** icons only (`Icons.*_rounded` / material_symbols packages). Filled axis for active/selected states. Never emoji-as-icon, never custom SVG icons.
- Both themes ship: light "Stitch Slate" (default) and dark "Midnight" (deep navy, never black). Every screen is designed in both (side-by-side in the HTML).
- Copy: English, playful, sentence case everywhere (buttons included). ALL-CAPS only for tiny tracked section labels (`INGREDIENTS · 8`). Use the exact strings in the mockups; they are drafted final copy.
- Hit targets ≥ 44dp. Cook-mode text ≥ 24sp.

## Design Tokens → Flutter

CSS originals in `tokens/*.css` (this bundle). Flutter mapping:

### Color (Material 3, seed `#3F51B5` "Moody Blue")
Light scheme (selected values — full set in `tokens/colors.css` `:root`):
- primary `#24389C`, onPrimary `#FFFFFF`, primaryContainer `#3F51B5`, onPrimaryContainer `#CACFFF`
- secondary `#4D5A9C`, secondaryContainer `#ABB7FF`, onSecondaryContainer `#394687`
- tertiary `#88003B`, tertiaryContainer `#B40050`, onTertiaryContainer `#FFC3CE` — **reserved for rare CTA moments** (only use in these designs: the ONE-TIME badge on the paywall, the favorite heart)
- error `#BA1A1A`; status greens/ambers: success `#22C55E`, warning `#F59E0B`, info `#3B82F6`
- surface `#F9F9FC`, scaffold background `#FAF8F0` (warm cream — use as `scaffoldBackgroundColor`), surfaceContainerLowest `#FFFFFF` (cards), surfaceContainerLow `#F3F3F6`, surfaceContainer `#EEEEF0`, surfaceContainerHigh `#E8E8EA` (chips, icon circles), surfaceContainerHighest `#E2E2E5`
- onSurface `#1A1C1E`, onSurfaceVariant `#454652`, outline `#757684`, outlineVariant `#C5C5D4` (hairlines drawn at ~50% alpha)

Dark scheme (`[data-theme="dark"]` block): primary `#BAC3FF`, onPrimary `#071A86`, primaryContainer `#293CA0`; scaffold/background `#0F1117`, surfaceContainerLowest `#0A0C11`, surfaceContainer `#161922`, surfaceContainerHigh `#1C1F2B`, surfaceContainerHighest `#262A36`, onSurface `#E4E2E6`, outlineVariant `#454652`. Elevation in dark = surface tinting, shadows softened (see `tokens/elevation.css`).

### Typography (google_fonts)
- **Plus Jakarta Sans** — display/headline/titles. Screen titles 22–23sp w700 (−0.01em); hero headlines (paywall) 26–29sp w700 (−0.02em); wordmark "MyReciBook" 23sp w800 primary color; card titles 13.5–15sp w600–700 (Inter ok at these sizes, mockups use Inter for ≤15sp).
- **Inter** — body/labels. Body 13.5–14sp w400–500; captions 12–12.5sp onSurfaceVariant; section labels 11sp w600, letter-spacing 0.9px, uppercase, onSurfaceVariant; monospace moments (file paths, counters) = platform mono, 11.5sp.

### Shape
radius: 8 buttons/small inputs · 12 list cards/inputs · 16 large cards/dialogs · 22 icon-squircles (paywall/cap) · 24 bottom sheets (top corners) · 28 phone frame (ignore) · full/stadium for pills: search bar, chips, segmented control, big CTAs (the primary CTA buttons in these mockups are stadium-shaped), FAB (18–20 radius square-ish is also acceptable per M3; mockups use circle).

### Spacing
4px grid: 4/8/12/16/24/32. Screen padding 20 horizontal. Card internal padding 12–16. Gap between stacked cards 11–12. Section label → card gap 12.

### Elevation & effects
- Card shadow (light): `0 4px 10px rgba(36,56,156,0.06)`; modal `0 8px 20px rgba(36,56,156,0.12)` — blue-tinted, subtle.
- Focus/selected glow: `0 0 12px 2px rgba(63,81,181,0.15)` (used on the selected storage card and the merge-prompt card).
- Glass (bottom nav, hero overlay buttons): translucent fill (`rgba(255,255,255,0.55)` light / `rgba(0,0,0,0.35)` dark) + 20–24 blur + 1px hairline border. Flutter: `BackdropFilter` + semi-transparent container.
- Motion: 150ms micro / 300ms standard / 500ms deliberate, easing `cubic-bezier(0.2,0,0,1)` (M3 emphasized). No bouncy curves. Respect reduced-motion.

## App shell
Bottom glass NavBar, floating (content scrolls under it, `extendBody: true`): 56dp pill, 4 tabs split 2+2 around a center FAB — **Cookbook** (menu_book) · **Grocery** (checklist) · [FAB] · **Plan** (calendar_month) · **Settings** (settings). Active tab = primary color + filled icon. FAB: 52dp, gradient `linear(135deg, primaryContainer → primary)`, white `add` icon, strong glow shadow `0 8px 16px 2px rgba(63,81,181,0.45)`. FAB opens the Import sheet (screen 1).

## Screens / Views

### 1. Import sheet (`#3a`)
- **Purpose:** single entry point for all imports: screenshots (primary), link (bonus), camera.
- **Layout:** modal bottom sheet over 45% scrim, top radius 24, grabber 36×4, padding 20. Title "Add to your book" (PJS 20 w700).
- Section `FROM YOUR SCREENSHOTS`: 4-column grid (8 gap) of 86dp-tall gallery tiles from the **system photo picker pre-filtered to screenshots**, newest first. Selected tiles: 2dp primary border + numbered badge (20dp primary circle, order number). Unselected: faint ring badge. Last tile: surfaceContainerHigh "234 more ›" → full picker.
- Segmented control (appears only when ≥2 selected): stadium container surfaceContainerHigh padding 3; selected segment = surfaceContainerLowest fill, primary text, card shadow. Options: "One recipe · 2 shots" / "2 separate recipes". **This decides stacked-multi-shot vs batch.**
- Section `OR FETCH FROM THE INTERNET`: pill input (hairline border, link icon, placeholder "Paste a link — TikTok, IG, blog…") + 44dp circular tonal (secondaryContainer) arrow_forward button. Caption below (12sp, onSurfaceVariant): "Links work when the recipe is written in the caption. Screenshots always work — that's why we like them."
- Divider hairline, then camera row: 40dp radius-12 surfaceContainerHigh tile w/ photo_camera icon; "Snap a page" w600 + caption "cookbook or grandma's card — handwriting welcome"; chevron_right.
- Primary CTA: filled stadium full-width 48dp "Rescue as one recipe" + trailing arrow_forward. Label mirrors the segmented choice ("Rescue 2 recipes" in batch mode).

### 2. Batch queue (`#3b`)
- **Purpose:** non-blocking progress for multi-imports; only flagged items demand attention.
- Title "Rescuing 4 recipes…" (PJS 22 w700) + text button "Hide" (primary 13 w600). Caption: "Keep browsing — we'll line them up for a quick check."
- Item cards (radius 12, hairline, card shadow, padding 12, 44×60 thumbnail left):
  - **Done:** title + caption "saved · looked complete"; trailing filled check_circle in success green.
  - **Flagged:** 1.5dp border in warning@55%; caption "1 line needs your eyes" in warning-mixed color; trailing tonal sm button "Review" → opens screen 3.
  - **Extracting:** title "Extracting…" + 6dp progress bar (surfaceContainerHigh track, primary fill).
  - **Waiting:** 65% opacity, caption "Waiting…".
- Dashed-border info card: "Not a recipe? We skip it and say so — no junk lands in your book."
- Footer row: outlined "Review flagged · 1" + filled "Done", both flex.
- **Behavior:** clean extractions save silently; queue persists as a header chip on Cookbook while running.

### 3. Extraction review (`#3c`) — the core moment
- **Purpose:** suggest-and-confirm editing of an AI extraction. **Never silently auto-save a low-confidence line** (report §6.3).
- Top bar: arrow_back · "Recipe rescued" + filled success check_circle (PJS 18 w700) · text button "Retry".
- Source row: 52×76 original-screenshot thumb (radius 8) · "Original screenshot" w600 + caption "tap to compare side-by-side" · 40dp circle surfaceContainerHigh swap_horiz button. Tapping swaps to a full-height original-vs-extracted compare.
- Title card (radius 12, card style): recipe title (PJS 18 w700) + edit icon. Inline-editable.
- Meta chips row: stadium surfaceContainerHigh chips w/ primary icons — "4 servings" (restaurant), "25 min" (schedule); "+ tag" chip is dashed-outline ghost.
- `INGREDIENTS · 8` card: one row per line (13.5sp, qty bold, hairline separators).
  - **Low-confidence row:** background warning@12%, radius 8, inset −8 horizontal; uncertain token gets dashed warning underline ("1 tsp?"); trailing "confirm" chip (stadium, 1.5dp warning border, w600). Tap = confirm (row normalizes) or edit. Expect ~1 flagged line per 20 (§6.3).
  - **Editing row:** text field with 1.5dp primary border + primary glow, trailing 36dp primary circle check button.
  - Overflow: "+ 3 more…" caption expands.
- `STEPS · 5` card: numbered rows, number in primary w700.
- Footer: toggle row — auto_delete icon + "Delete the screenshot after saving" + M3 switch (**on in mockup; ship default OFF**, §6.5 cleanup nudge) — then filled stadium "Save to cookbook".

### 4. Cookbook home (`#3d`, empty: `#4b`)
- Header: wordmark lockup (filled menu_book 26 + "MyReciBook" PJS 23 w800, both primary) + trailing success Badge "Synced" w/ cloud_done (storage status: "Synced" / "On this phone"; quiet, never a nag).
- Search: pill search bar, placeholder "Search your cookbook…".
- Filter chips: horizontal scroll row bleeding to screen edge (last chip half-visible as scroll affordance): "All" (selected) · "Favorites" (favorite) · "Quick" (bolt) · "Sweet" (cake). Selected chip = primaryContainer-tinted per DS Chip.
- Grid: 2 columns, 12 gap. Card = radius 12, hairline, card shadow; 108dp cover (the recipe's **original screenshot, auto-cropped** — zero-effort covers) + padding 9/11: title 13.5 w600 (2-line max) + caption 11.5 onSurfaceVariant "25 min · 4 servings".
- Bottom glass NavBar (shell above), Cookbook active.
- **Empty state (`#4b`):** centered — menu_book icon in tinted circle, title "Your book is empty (for now)", message "Somewhere in your camera roll, a pile of recipes is waiting to be rescued.", filled button "Rescue your first recipe" (add icon), caption "or paste a link — we'll take those too".

### 5. Recipe detail (`#3e`)
- Hero 210dp: cover image full-bleed; glass circle buttons top: arrow_back (left), favorite (right, filled tertiaryContainer heart when favorited); bottom-right glass pill "original ⇄" (swap_horiz 15) → flips hero between cover crop and full original screenshot (provenance affordance, same as review).
- Title PJS 23 w700. Meta row: "25 min" chip (schedule) + **servings stepper**: stadium hairline pill [34dp − circle] "4 servings" w600 [34dp + circle, surfaceContainerHigh]. **Stepping rescales every ingredient quantity live and propagates to the grocery list** (§6.3 — the propagation bug rivals ship; model list as live view of plan).
- `INGREDIENTS` card: checkbox rows (18dp, radius 6, 2dp outline border; checked = primary fill + white check + strikethrough muted text). Qty bold.
- `STEPS` card: numbered paragraphs, primary numbers; step 1 emphasized, later steps muted until cook mode.
- Footer: filled "Start cooking" (play_arrow, flex 1.5) + tonal "Grocery" (playlist_add, flex 1) — one-tap whole-recipe add, checked-off ingredients excluded.

### 6. Cook mode (`#3f`)
- **Purpose:** hands-off step-by-step. Wakelock on ("Screen stays awake while you cook" caption bottom-center 11.5sp).
- Top: 5-segment progress (5dp bars, radius 3; done/current = primary, rest surfaceContainerHighest) · "Step 2 of 5 · Creamy garlic pasta" 13 w600 onSurfaceVariant · 36dp close circle.
- Center (flex, vertically centered): step text PJS w600 **27sp** line-height 1.4, center-aligned.
- `FOR THIS STEP`: stadium hairline chips on surfaceContainerLowest with this step's ingredients only, quantities bold and **scaled to chosen servings**.
- Tonal full-width button "Start 1 min timer" (timer icon) — durations parsed from step text auto-generate timer chips.
- Bottom: 60dp tap zones — back (flex 1, surfaceContainerHigh circle-pill, arrow_back) + "Next →" (flex 2, filled primary stadium, 16sp w600). Whole zones tappable (steamy-hands friendly).

### 7. Paywall (`#3g`)
- **Purpose:** hard paywall after 5 free rescues. Pay-once with **stated fair-use AI cap — the cap must appear on this screen and in the store listing from day one** (context.md constraint 2; Play Guideline analog of §6.2 risk 1).
- Close circle top-right. Centered: 68dp radius-22 secondaryContainer squircle w/ filled menu_book 34; headline "Pay once.⏎Cook forever." PJS 29 w700 −0.02em; sub "No subscription. No account. Ever." 14 onSurfaceVariant.
- Price card: radius 16, **1.5dp primary border**, modal shadow, padding 16. Row: "$24.99" PJS 24 w800 + badge "ONE-TIME" (radius 8, tertiaryContainer bg, onTertiaryContainer text, 11.5 w700 — the app's only tertiary moment). Checklist (13.5sp, primary check icons): "Every recipe, forever, in your storage" / "600 AI rescues a year — fair-use cap, in writing" / "A grocery list that actually merges" / "All future features included".
- Expander card: "Why not a subscription?" w600 + expand icon; expanded body: "Because your recipe box shouldn't have a landlord. You buy MyReciBook like you'd buy a good knife: once."
- Filled stadium "Unlock MyReciBook — $24.99"; caption "Restore purchase · Google Play billing" (Restore = primary w600, tappable).
- **Placeholder decisions:** $24.99 and 600/yr are working numbers — confirm before store listing.

### 8. Storage setup (`#3h`)
- **Purpose:** BYOS. Local is default; connectors optional. No account exists anywhere.
- Top bar arrow_back + "Storage". Headline "Where should your recipes live?" PJS 23 w700; sub "Plain files, one per recipe. Yours."
- Option cards (radius 12, padding 13, 40dp radius-12 icon tile + texts + trailing):
  - **This phone** — selected: 1.5dp primary border + primary glow; secondaryContainer icon tile (phone_android); caption "zero setup · works offline"; trailing filled primary check_circle.
  - **Google Drive** — caption "app folder only — we can't see the rest" (`drive.file` scope, §6.5); trailing outlined sm "Connect".
  - **Dropbox** — caption "app folder only"; trailing outlined sm "Connect".
- `WHAT A RECIPE LOOKS LIKE ON DISK`: mono code card (surfaceContainerHigh, radius 12, 11.5sp/1.65): path line `MyReciBook/recipes/creamy-garlic-pasta.json` in primary w600, then dimmed 2-line JSON preview.
- Dashed info card: "Move, export or leave anytime. If MyReciBook vanished tomorrow, your recipes wouldn't."
- Filled stadium "Continue" + trailing arrow_forward.

### 9. Grocery list (`#4a`) — the retention layer
- **Purpose:** fix the three list failures rivals ship (§6.3): silent duplicates, stale amounts, locked categories.
- Header: "Grocery" PJS 22 w700 + caption "9 items · from 3 planned recipes"; trailing ios_share circle.
- **Sync receipt banner** (tonal: secondaryContainer@40% mix, radius 12): event_repeat icon primary + "Salmon bumped to 4 servings — 3 amounts updated." + dismiss ×. Appears whenever plan/servings changes propagate. List = live view of the plan, never a snapshot.
- **Merge prompt card** (1.5dp primary border + glow): "Same thing?" w600; "**2 lemons** (Pasta) + **4 lemons** (Salmon)" (bold quantities, muted sources); buttons tonal sm "Merge · 6 lemons" + text sm "Keep apart". **Suggest-and-confirm — never merge silently** (§6.3 cross-unit merging is the graveyard feature; confirmed merges are remembered).
- Aisle sections: label `PRODUCE · 2` etc. + item cards (checkbox rows like detail screen; trailing micro-caption 11sp: "2 recipes" provenance, or "moved here by you").
  - `ASIAN PANTRY · 1` carries a "your aisle" pin chip (push_pin 12 + primary text 10 on surfaceContainerHigh stadium) — **user-created category; corrections are remembered per store** and re-applied to future items.
  - **Staple row** (olive oil): 55% opacity, "staple" chip (radius 8, surfaceContainerHigh, 10.5 w600); footer caption "Staples stay quiet unless you tap them." Staples never auto-add; tap to activate.
- Checked rows: primary-filled checkbox + strikethrough muted text; stay in place until "Clear checked" (overflow menu).
- Bottom glass NavBar, Grocery active.

### 10. Extraction failed (`#4c`)
- Centered: 100×140 striped thumb w/ no_meals icon; title "That one kept its secrets" PJS 21 w700; body (13.5/1.55, max 270dp): "We read it twice and couldn't find a recipe. It stays put in your gallery — nothing was deleted, and it didn't count against your rescues." — three reassurances, always: gallery untouched · nothing deleted · **cap unspent** (failed extractions never decrement the cap).
- Buttons: filled "Try again" (refresh) + outlined "Type it in by hand" (edit), both full-width stacked.

### 11. Fair-use cap reached (`#4d`)
- Close top-right. Centered: 68dp secondaryContainer squircle w/ hourglass_top; title "You've rescued a lot this year" PJS 26 w700; sub "That's the fair-use cap we promised at purchase. It resets on 1 January."
- Meter card (radius 16): row "2026 AI rescues" w600 + mono "600 / 600"; 8dp full primary bar; caption "Typing or pasting recipes in yourself is always unlimited — the cap only meters the AI."
- Filled "Add 200 rescues — $2.99" + text "Type it in by hand"; footer caption "Everything you own keeps working, forever."
- ⚠ **The top-up pack is an unconfirmed product decision** (report §6.2 Mechanism B — precedented via consumable credits, must never expire). Build the screen; gate the top-up button behind a config flag until confirmed.

## Interactions & Behavior (cross-screen)
- **Import entry points:** FAB → import sheet; Android share sheet (image/s or URL shared to app) → jumps straight to extraction with the same pipeline; both honor multi-image "one recipe vs separate" choice.
- **Extraction pipeline UX contract:** ML Kit on-device OCR → cloud structuring via thin proxy (context.md constraint 1/3). Every extraction returns per-line confidence; lines below threshold render the flagged treatment (screen 3). Clean batch items auto-save; flagged ones queue.
- **Provenance:** the original screenshot is stored with the recipe and reachable from review (swap), detail (hero flip), and compare view. Deleting the source screenshot (opt-in toggle) never deletes the stored copy inside the recipe file.
- **Scaling:** servings stepper on detail is the single source of truth; ingredient quantities, cook-mode chips, and grocery amounts all derive from it live.
- **Navigation:** bottom nav persists on Cookbook/Grocery/Plan/Settings; import sheet, review, detail, cook mode, paywall, storage are pushed routes/sheets without nav. Max one sheet over any screen (user preference: shallow depth).
- **Transitions:** sheets slide up 300ms emphasized easing; cook-mode steps crossfade/slide 300ms; FAB icon crossfades. Nothing bouncy.
- **Loading:** extraction progress = indeterminate → determinate bar per item (batch queue pattern). Never a full-screen blocking spinner.

## State Management (suggested)
- `RecipeFile` (one JSON per recipe, user storage — constraint 3): title, servings, ingredients[qty,unit,item,prep,confidence], steps[text,duration?], tags, source{screenshotRefs[], url?}, timesCooked.
- `ExtractionJob`: queued → extracting(progress) → needsReview(flags[]) | saved | failed(reason) | skippedNotARecipe.
- `GroceryList` derived live from `MealPlan` + manual adds; `MergeSuggestion(pending|accepted|dismissed)`; per-store `AisleMapping{item→aisle}` (persisted corrections); `staples: Set<item>`.
- `Entitlement`: freeRescuesUsed(0–5), purchased(bool), capUsed/capTotal(year), topUpBalance. Cap counter mirrors the proxy's per-install count (constraint 3 amendment).
- `StorageBackend`: local (default) | drive(appFolder) | dropbox(appFolder); sync = last-write-wins per file + conflicted-copy recovery (§6.5).

## Assets
- Fonts: Plus Jakarta Sans + Inter (Google Fonts / google_fonts package).
- Icons: Material Symbols Rounded only. Used glyphs: menu_book, checklist, calendar_month, settings, add, search, favorite, bolt, cake, schedule, restaurant, swap_horiz, edit, check, check_circle, close, arrow_back, arrow_forward, play_arrow, remove, timer, photo_camera, link, chevron_right, cloud_done, phone_android, add_to_drive, cloud, auto_delete, refresh, no_meals, hourglass_top, event_repeat, ios_share, push_pin, expand_less, signal_cellular_alt, wifi, battery_5_bar.
- No logo mark exists yet — the wordmark lockup (filled menu_book + "MyReciBook" in Plus Jakarta Sans 800, primary) is the interim brand. Striped placeholder areas = user screenshots at runtime.

## Product constraints that must survive implementation
1. Suggest-and-confirm everywhere AI guesses (extraction lines, grocery merges) — no silent automation.
2. One JSON file per recipe in user-owned storage; no backend beyond the stateless extraction proxy (+ cap counter).
3. Fair-use cap stated at purchase and enforced transparently; hand-entry always unlimited; failed extractions don't count.
4. Pay-once, hard paywall; never promise "unlimited forever."
5. Link import is a degradable bonus behind a kill-switch flag — its breakage must never take screenshot import down with it.

## Files
- `design/MyReciBook Mockups.dc.html` — all screens; hi-fi = sections `#3a`–`#3h`, `#4a`–`#4d` (each rendered light + dark); turns 1–2 = annotated wireframes (rationale).
- `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css`, `tokens/elevation.css` — the design-token source of truth referenced above.
